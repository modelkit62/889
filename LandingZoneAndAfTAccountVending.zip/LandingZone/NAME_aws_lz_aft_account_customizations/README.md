# NAME AWS LZ AFT Account Customizations

This is one of the repositories that is part of the AWS Control Tower Account Factory for Terraform (AFT) feature used on the NAME AWS Landing Zone. See the [Infrastucture team repositories](https://github.com/orgs/NAME/teams/infrastructure/repositories) to access the repositories.

* [NAME_aws_account_factory_vending](https://github.com/NAME/NAME_aws_account_factory_vending)
* [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations)
* [NAME_aws_lz_aft_account_provisioning_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_provisioning_customizations)
* [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) 
* [NAME_aws_lz_aft_global_customizations](https://github.com/NAME/NAME_aws_lz_aft_global_customizations)

## Intro

This repository is used to define customizations that are applied to individual AWS accounts.

These customizations are applied to the account after the initial provisioning customizations (see [repository](https://github.com/NAME/NAME_aws_lz_aft_account_provisioning_customizations)) and global customizations (see [repository](https://github.com/NAME/NAME_aws_lz_aft_global_customizations)) have been applied.

Examples:
* Connect accounts to centralised hub networking.
* Deploy external connectivity such as Internet Gateways (IGWs) directly to the account.

## Usage

Create a new folder for each new AWS account that is created via AFT / [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request).

This reposity is used by CloudFormation in the AFT account when the [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) repository is updated.

## Directory Info

Each root folder directory is related to a specific individual AWS Account specified in [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) repository. 

The name of the folder is used in the [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) repository when a new AWS account request is made. The name of the field it needs to match is called `account_customizations_name`.

In each root folder directory is a `api_helpers` folder and `terraform` folder where custom configuration can be added.

If your custom configurations is in the form of Python programs or scripts, place those under `api_helpers/python` folder in your repository.

If your custom configurations is in the form of Bash scripts, place those under `api_helpers` folder in your repository.

If your custom configurations is in the form of Terraform, place those under the `terraform` folder in your repository.

## API Helpers
The purpose of API helpers is to perform actions that cannot be performed within Terraform.

### Python
The api_helpers/python folder contains a requirements.txt, where you can specify libraries/packages to be installed via PIP.

### Bash
This is where you define what runs before/after Terraform, as well as the order the Python scripts execute, along with any command line parameters. These bash scripts can be extended to perform other actions, such as leveraging the AWS CLI or performing additional/custom Bash scripting.

- pre-api-helpers.sh - Actions to execute prior to running Terraform.
- post-api-helpers.sh - Actions to execute after running Terraform.

### Sample api-helpers.sh

Sample #1 - Using AWS CLI to query for resources, save to a variable, and then pass to a script. In the example below, all running instances are queried, stopped, and started using AWS CLI and custom Python scritpts.
```
instances=$(aws ec2 describe-instances --filters "Name=instance-state-name,Values=running")
python ./python/source/stop_instances.py --instances $instances
sleep 10s
python ./python/source/start_instances.py --instances $instances
```

Sample #2 - Query a 3rd party IPAM solution, and save the given CIDR to AWS Parameter Store. This SSM parameter could be leveraged from Terraform using a data object to create a VPC.
```
account = $(aws sts get-caller-identity --query Account --output text)
region = $(aws ec2 describe-availability-zones --query 'AvailabilityZones[0].[RegionName]' --output text)
cidr = $(python ./python/source/get_cidr_range.py)
aws ssm put-parameter --name /$account/$region/vpc/cidr --value $cidr
```
