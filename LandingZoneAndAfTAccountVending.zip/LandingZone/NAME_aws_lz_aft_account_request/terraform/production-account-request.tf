# # NAME Production account in Production OU
# module "production_ou_NAME_production_account" {
#   source = "./modules/aft-account-request"

#   control_tower_parameters = {
#     AccountEmail = "NAMEawslz+NAME@NAMEs.com"

#     # The name of the new account
#     AccountName  = "NAME-production"

#     # Top level OU
#     # ManagedOrganizationalUnit = "Workloads"

#     # Nested OU
#     # For Sandbox:         "Workloads (ou-?)"
#     # For Non-Production:  "Workloads (ou-?)"
#     # For Production:      "Workloads (ou-?)"
#     ManagedOrganizationalUnit = "Workloads (ou-?)"

#     SSOUserEmail     = "NAMEawslz+NAME@NAMEs.com"
#     SSOUserFirstName = "NAME"
#     SSOUserLastName  = "SSOAdminAccess"
#   }

#   # Example Tags
#   account_tags = {
#     "ABC:Owner"       = "john.doe@amazon.com"
#     "ABC:Division"    = "ENT"
#     "ABC:Environment" = "Dev"
#     "ABC:CostCenter"  = "123456"
#     "ABC:Vended"      = "true"
#     "ABC:DivCode"     = "102"
#     "ABC:BUCode"      = "ABC003"
#     "ABC:Project"     = "123456"
#   }

#   # Reason for new acount
#   change_management_parameters = {
#     change_requested_by = "Nick Walters"
#     change_reason       = "Add the NAME Production account"
#   }

#   custom_fields = {
#     custom1 = "a"
#     custom2 = "b"
#   }

#   # This value needs to match the name of a folder in the
#   # NAME_aws_lz_aft_account_customizations repository
#   account_customizations_name = "production_ou_NAME_production_account"
# }

# # NAME Production account in Production OU
# module "production_ou_NAME_production_account" {
#   source = "./modules/aft-account-request"

#   control_tower_parameters = {
#     AccountEmail = "NAMEawslz+NAME@NAMEs.com"

#     # The name of the new account
#     AccountName  = "NAME-production"

#     # Top level OU
#     # ManagedOrganizationalUnit = "Workloads"

#     # Nested OU
#     # For Sandbox:         "Workloads (ou-?)"
#     # For Non-Production:  "Workloads (ou-?)"
#     # For Production:      "Workloads (ou-?)"
#     ManagedOrganizationalUnit = "Workloads (ou-?)"

#     SSOUserEmail     = "NAMEawslz+NAME@NAMEs.com"
#     SSOUserFirstName = "NAME"
#     SSOUserLastName  = "SSOAdminAccess"
#   }

#   # Example Tags
#   account_tags = {
#     "ABC:Owner"       = "john.doe@amazon.com"
#     "ABC:Division"    = "ENT"
#     "ABC:Environment" = "Dev"
#     "ABC:CostCenter"  = "123456"
#     "ABC:Vended"      = "true"
#     "ABC:DivCode"     = "102"
#     "ABC:BUCode"      = "ABC003"
#     "ABC:Project"     = "123456"
#   }

#   # Reason for new acount
#   change_management_parameters = {
#     change_requested_by = "Nick Walters"
#     change_reason       = "Add the NAME Production account"
#   }

#   custom_fields = {
#     custom1 = "a"
#     custom2 = "b"
#   }

#   # This value needs to match the name of a folder in the
#   # NAME_aws_lz_aft_account_customizations repository
#   account_customizations_name = "production_ou_NAME_production_account"
# }
