# NAME AWS LZ AFT Account Request

This is one of the repositories that is part of the AWS Control Tower Account Factory for Terraform (AFT) feature used on the NAME AWS Landing Zone. See the [Infrastucture team repositories](https://github.com/orgs/NAME/teams/infrastructure/repositories) to access the repositories.

* [NAME_aws_account_factory_vending](https://github.com/NAME/NAME_aws_account_factory_vending)
* [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations)
* [NAME_aws_lz_aft_account_provisioning_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_provisioning_customizations)
* [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request)
* [NAME_aws_lz_aft_global_customizations](https://github.com/NAME/NAME_aws_lz_aft_global_customizations)

## Intro

This repository contains a Terraform module that is used to create new AWS accounts.

New AWS accounts are added to the relevant OU by adding new configuration into one of the following files:

* terraform/sandbox-account-request.tf
* terraform/non-production-account-request.tf
* terraform/production-account-request.tf

The field `account_customizations_name` in each of the above files must match the name of a folder in the [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations) repository when creating a new AWS account.

The fields `SSOUserEmail`, `SSOUserFirstName`, and `SSOUserLastName` in each of the above files will create a SSO user in the NAME AWS Landing Zone root account AWS Identity Center.

## CI/CD

Commits to this repository main branch will start the AFT CI/CD pipeline on the the AFT AWS account automatically. 

This is achieved by a AWS GitHub Organisation App that a GitHub Organisation Admin who has admin access to the AWS account too as well can approve. The App creates a AWS CodeConnection link to this repository and starts the AWS CodePipeline process. The connection in GitHub should have already been added as part of the NAME AWS Landing Zone set up, just need to add this repositoy to the list of allowed repositories AWS can connect to in the GitHub Organisation settings.

## AFT CI/CD pipeline

* In the AFT account, in AWS CodePipeline there should be two pipelines one for this repository and another for the [NAME_aws_lz_aft_account_provisioning_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_provisioning_customizations) repository.

* In the AFT account it uses different AWS Step functions state machines to handle the above two AWS CodePipelines. Look for the state machine called `aft-account-provisioning-framework`. 

* **The `aft-account-provisioning-framework` reports back everything is okay even when there is a failure. Please log into the AFT account and check this has passed.**

* Can open the state machine to see the state machine instance diagram and where it might have failed. There might be a race condition in the first deployment, and it just needs to be re-run. Try re-running the whole Step Function.

* The state machine will then call the other three state machines that can be seen in the AFT account. 

* It will delete the default VPC in the new account, enable CloudTrail and enrol Enterprise Support. 

## Add an Account

1. Add the account into one of the three files and merge the changes onto the main branch:

* terraform/sandbox-account-request.tf
* terraform/non-production-account-request.tf
* terraform/production-account-request.tf

2. Check the AFT account AWS CodePipeline, AWS Step Function (look at the state machine diagram to ensure it run successfully) and and AWS CodeBuild services.

3. Once the AWS Services have run successfully go to the NAME Landing Zone [repository](https://github.com/NAME/NAME_aws_landing_zone_configuration) and add the details of the newly created AWS account in the `accounts-config.yaml` file in this format:

```
  - name: account-name
    description: example
    email: NAMEawslz+example@NAMEs.com
    organizationalUnit: Workloads/Non-Production
```

Merge the change onto the main branch to start a new run of the Landing Zone CodePipeline CI/CD and complete the manual approve step in the root AWS account.

## Remove an Account

0. Record the AWS account number ID to be deleted.
1. Follow the steps the on the NAME Landing Zone [repository](https://github.com/NAME/NAME_aws_landing_zone_configuration) to remove the AWS account from the AWS Organisation and AWS Control Tower. The account should reside in the SuspendedOU and be excluded from the AWS Control Tower.
2. Delete the account from this repository and the [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations). Push the changes to main branches. After that need to clean up the AWS S3 buckets and DynamoDB tables in the AFT account.
3. Go to the AFT account AWS S3 bucket called `aft-backend-ABC-primary-region` and remove the items that have a matching AWS account number ID to be deleted.
4. Delete the AWS S3 bucket that have a matching AWS account number ID to be deleted.
5. Go to the AFT account DynamoDB table called `aft-backend-ABC`, explore the items and delete any items that have a matching AWS account number ID to be deleted.
6. Go to the AFT account DynamoDB table called `aft-request-audit`, explore the items and delete any items that have a matching AWS account number ID to be deleted.

## SCP

There are SCPs applied to the AFT OU, AFT account, Workload OU, nested Workload OUs, and any workload AWS accounts created by the AFT. The SCPs restrict access to AWS resources.

If the AWS CodePipeline, AWS Step Function or AWS CodeBuild run fails when making changes in the AFT account, it might be because a customisation has been added to the [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations) repository, the [NAME_aws_lz_aft_account_provisioning_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_provisioning_customizations) repository, or the [NAME_aws_lz_aft_global_customizations](https://github.com/NAME/NAME_aws_lz_aft_global_customizations) repository but the action is denied in the SCP.

Look at the AWS CodePipeline, AWS Step Function or AWS CodeBuild runs to see if there are any IAM permission denied errors and if so add the IAM role to the SCP in the NAME Landing Zone [repository](https://github.com/NAME/NAME_aws_landing_zone_configuration). Merge the change onto the main branch to start a new run of the Landing Zone CodePipeline CI/CD and complete the manual approve step in the root AWS account.
