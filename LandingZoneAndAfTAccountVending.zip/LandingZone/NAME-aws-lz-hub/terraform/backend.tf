terraform {
  backend "s3" {
    bucket       = "NAME-aws-lz-hub-tfstate"
    key          = "NAME-aws-lz-hub-terraform-statefile.tfstate"
    region       = "eu-west-2"
    use_lockfile = true
    encrypt      = true
  }
}
