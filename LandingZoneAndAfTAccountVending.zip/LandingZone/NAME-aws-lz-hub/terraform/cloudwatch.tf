resource "aws_cloudwatch_log_group" "vpc_flow_logs" {
  name              = "/aws/vpc/NAME-network-vpc-flow-logs"
  retention_in_days = 3653
  kms_key_id        = data.aws_kms_key.accelerator_cloudwatch_key.arn
  skip_destroy      = false
}

resource "aws_cloudwatch_log_group" "network_firewall_alert_log_group" {
  name              = "/aws/network-firewall/alert-logs"
  retention_in_days = 3653
  kms_key_id        = data.aws_kms_key.accelerator_cloudwatch_key.arn
  skip_destroy      = false
}

# Create a Cloudwatch Log Group for AWS Network Firewall Flows
resource "aws_cloudwatch_log_group" "network_firewall_flow_log_group" {
  name              = "/aws/network-firewall/flows"
  retention_in_days = 3653
  kms_key_id        = data.aws_kms_key.accelerator_cloudwatch_key.arn
  skip_destroy      = false
}
