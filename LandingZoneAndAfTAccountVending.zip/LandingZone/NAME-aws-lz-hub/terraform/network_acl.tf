# Remove this when deploy to two subnets
resource "aws_network_acl" "block_outbound_subnets_not_in_use" {
  vpc_id     = aws_vpc.main.id
  subnet_ids = [aws_subnet.nat_gateway[1].id, aws_subnet.network_firewall[1].id, aws_subnet.tgw[1].id]

  # Allow all inbound (optional)
  ingress {
    rule_no    = 100
    protocol   = "-1"
    action     = "allow"
    cidr_block = "0.0.0.0/0"
    from_port  = 0
    to_port    = 0
  }

  # Deny all outbound
  egress {
    rule_no    = 100
    protocol   = "-1"
    action     = "deny"
    cidr_block = "0.0.0.0/0"
    from_port  = 0
    to_port    = 0
  }

  tags = {
    Name = "block_outbound_subnets_not_in_use"
  }
}