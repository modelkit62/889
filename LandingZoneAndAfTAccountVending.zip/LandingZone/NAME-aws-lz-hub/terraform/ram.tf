# Create the RAM Share
resource "aws_ram_resource_share" "tgw" {
  name                      = "NAME-main-vpc-tgw-share"
  allow_external_principals = false
}

# Share the TGW
resource "aws_ram_resource_association" "transit_gateway_share" {
  resource_arn       = aws_ec2_transit_gateway.tgw.arn
  resource_share_arn = aws_ram_resource_share.tgw.arn
}

# Create an association between the RAM and the NAME AWS Org Prod OU
resource "aws_ram_principal_association" "prod_ou" {
  principal          = local.prod_ou_arn
  resource_share_arn = aws_ram_resource_share.tgw.arn
}

# Create an association between the RAM and the NAME AWS Org Non Prod OU
resource "aws_ram_principal_association" "non_prod_ou" {
  principal          = local.non_prod_ou_arn
  resource_share_arn = aws_ram_resource_share.tgw.arn
}
