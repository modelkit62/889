locals {

  # Naming conventions
  # prefix = "/${var.owner}/${var.product}"
  name = "${var.owner}-${var.product}"

  default_tags = var.tags

  super_cidr           = "10.0.0.0/8"
  vpc_cidr             = "10.100.0.0/24"
  NAME_cidr            = "10.101.0.0/24"

  number_of_subnets = 2
  deploy_to_subnets = 1

  prod_ou_arn     = "arn:aws:organizations::??:ou/o-??/ou-??"
  non_prod_ou_arn = "arn:aws:organizations::??:ou/o-??/ou-??"
}

# Used to get the AWS account number
# data "aws_caller_identity" "current" {}
