resource "aws_networkfirewall_firewall" "vpc_network_firewall" {
  name                = "NetworkFirewall"
  firewall_policy_arn = aws_networkfirewall_firewall_policy.vpc_network_firewall_policy.arn
  vpc_id              = aws_vpc.main.id

  # Use this when use an AWS Network Firewall to single Subnet
  subnet_mapping {
    subnet_id = aws_subnet.network_firewall[0].id
  }

  # Use this when need to apply the AWS Network Firewall to multiple Subnets
  # also update the route in "aws_route_table" "tgw_subnet_route_table"
  # also update the route in "aws_route_table" "public_subnet_route_table"
  #   dynamic "subnet_mapping" {
  #     for_each = aws_subnet.network_firewall[*].id
  #     content {
  #       subnet_id = subnet_mapping.value
  #     }
  #   }

}

resource "aws_networkfirewall_firewall_policy" "vpc_network_firewall_policy" {
  name = "firewall-policy"
  firewall_policy {
    stateless_default_actions          = ["aws:forward_to_sfe"]
    stateless_fragment_default_actions = ["aws:forward_to_sfe"]
    stateless_rule_group_reference {
      priority     = 20
      resource_arn = aws_networkfirewall_rule_group.drop_icmp.arn
    }
    stateful_rule_group_reference {
      resource_arn = aws_networkfirewall_rule_group.block_domains.arn
    }
    stateful_rule_group_reference {
      resource_arn = aws_networkfirewall_rule_group.block_public_dns_resolvers.arn
    }
    stateful_rule_group_reference {
      resource_arn = aws_networkfirewall_rule_group.drop_non_http_between_vpcs.arn
    }
  }
}


### Stateless Rules

resource "aws_networkfirewall_rule_group" "drop_icmp" {
  capacity = 1
  name     = "drop-icmp"
  type     = "STATELESS"
  rule_group {
    rules_source {
      stateless_rules_and_custom_actions {
        stateless_rule {
          priority = 1
          rule_definition {
            actions = ["aws:drop"]
            match_attributes {
              protocols = [1]
              source {
                address_definition = "0.0.0.0/0"
              }
              destination {
                address_definition = "0.0.0.0/0"
              }
            }
          }
        }
      }
    }
  }
}

resource "aws_networkfirewall_rule_group" "drop_non_http_between_vpcs" {
  capacity = 100
  name     = "drop-non-http-between-vpcs"
  type     = "STATEFUL"
  rule_group {
    rule_variables {
      ip_sets {
        key = "SPOKE_VPCS"
        ip_set {
          definition = [local.super_cidr]
        }
      }
    }
    rules_source {
      rules_string = <<EOF
      drop tcp $SPOKE_VPCS any <> $SPOKE_VPCS any (msg:"Blocked TCP that is not HTTP"; flow:established; app-layer-protocol:!http; sid:100; rev:1;)
      drop ip $SPOKE_VPCS any <> $SPOKE_VPCS any (msg: "Block non-TCP traffic."; ip_proto:!TCP;sid:200; rev:1;)
      EOF
    }
  }
}

resource "aws_networkfirewall_rule_group" "block_public_dns_resolvers" {
  capacity = 1
  name     = "block-public-dns"
  type     = "STATEFUL"
  rule_group {
    rules_source {
      stateful_rule {
        action = "DROP"
        header {
          destination      = "ANY"
          destination_port = "ANY"
          direction        = "ANY"
          protocol         = "DNS"
          source           = "ANY"
          source_port      = "ANY"
        }
        rule_option {
          keyword  = "sid"
          settings = ["50"]
        }
      }
    }
  }
}

resource "aws_networkfirewall_rule_group" "block_domains" {
  capacity = 100
  name     = "block-domains"
  type     = "STATEFUL"
  rule_group {
    rule_variables {
      ip_sets {
        key = "HOME_NET"
        ip_set {
          definition = [local.NAME_cidr]
        }
      }
    }
    rules_source {
      rules_source_list {
        generated_rules_type = "DENYLIST"
        target_types         = ["HTTP_HOST", "TLS_SNI"]
        # Examples
        targets = [".facebook.com", ".twitter.com"]
      }
    }
  }
}

resource "aws_networkfirewall_logging_configuration" "network_firewall_logging_configuration" {
  firewall_arn = aws_networkfirewall_firewall.vpc_network_firewall.arn
  logging_configuration {
    log_destination_config {
      log_destination = {
        logGroup = aws_cloudwatch_log_group.network_firewall_alert_log_group.name
      }
      log_destination_type = "CloudWatchLogs"
      log_type             = "ALERT"
    }
    log_destination_config {
      log_destination = {
        logGroup = aws_cloudwatch_log_group.network_firewall_flow_log_group.name
      }
      log_destination_type = "CloudWatchLogs"
      log_type             = "FLOW"
    }
  }
}
