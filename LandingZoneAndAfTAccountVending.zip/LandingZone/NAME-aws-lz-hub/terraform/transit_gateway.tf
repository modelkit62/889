# Create the TGW
resource "aws_ec2_transit_gateway" "tgw" {
  description                     = "NAME AWS Landing Zone TGW"
  auto_accept_shared_attachments  = "enable"
  default_route_table_association = "disable"
  default_route_table_propagation = "disable"

  tags = {
    Name = "NAME-landing-zone-transit-gateway"
  }
}

# Create a route table to handle the connections between hub TGW and the hub VPC that has Network Firewall and NAT Gateway.
# Outbound data
resource "aws_ec2_transit_gateway_route_table" "hub_route_table" {
  transit_gateway_id = aws_ec2_transit_gateway.tgw.id
  tags = {
    Name = "hub-route-table"
  }
}

# Create a hub TGW attachment. Needed to create route tables routes to the TGW.
resource "aws_ec2_transit_gateway_vpc_attachment" "hub_vpc_tgw_attachment" {
  subnet_ids                                      = aws_subnet.tgw[*].id
  transit_gateway_id                              = aws_ec2_transit_gateway.tgw.id
  vpc_id                                          = aws_vpc.main.id
  transit_gateway_default_route_table_association = false
  appliance_mode_support                          = "enable"
  tags = {
    Name = "hub-tgw-vpc-attachment"
  }
}

# Create a association link between the hub TGW attachment and the hub route table
resource "aws_ec2_transit_gateway_route_table_association" "hub_vpc_tgw_attachment_rt_association" {
  transit_gateway_attachment_id  = aws_ec2_transit_gateway_vpc_attachment.hub_vpc_tgw_attachment.id
  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.hub_route_table.id
}

# Create a second route table to handle the connections between the hub TGW and the various spoke vpc's
# Inbound data
resource "aws_ec2_transit_gateway_route_table" "spoke_vpcs_route_table" {
  transit_gateway_id = aws_ec2_transit_gateway.tgw.id
  tags = {
    Name = "spoke-vpcs-route-table"
  }
}

# Create a propagation link between the hub TGW attachment and spoke vpc's route table
resource "aws_ec2_transit_gateway_route_table_propagation" "spoke_route_table_propagate_hub_vpc" {
  transit_gateway_attachment_id  = aws_ec2_transit_gateway_vpc_attachment.hub_vpc_tgw_attachment.id
  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.spoke_vpcs_route_table.id
}

# Create a route in the above route table between the TGW and spoke vpc's
resource "aws_ec2_transit_gateway_route" "spoke_route_table_default_route" {
  transit_gateway_attachment_id  = aws_ec2_transit_gateway_vpc_attachment.hub_vpc_tgw_attachment.id
  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.spoke_vpcs_route_table.id
  destination_cidr_block         = "0.0.0.0/0"
}

# Spoke VPC Attachments

# Get the NAME Test TGW Attachment
data "aws_ec2_transit_gateway_vpc_attachment" "NAME_test_vpc_tgw_attachment" {
  # Get the value from the NAME Test account
  id = "tgw-attach-?"
}

# Create a association link between the NAME Test TGW attachment and the spoke route table
resource "aws_ec2_transit_gateway_route_table_association" "NAME_test_tgw_rt_association" {
  transit_gateway_attachment_id  = data.aws_ec2_transit_gateway_vpc_attachment.NAME_test_vpc_tgw_attachment.id
  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.spoke_vpcs_route_table.id
}

# Create a propagation link between the NAME Test TGW attachment and hub route table
resource "aws_ec2_transit_gateway_route_table_propagation" "hub_route_table_propagate_NAME_test_vpc" {
  transit_gateway_attachment_id  = data.aws_ec2_transit_gateway_vpc_attachment.NAME_test_vpc_tgw_attachment.id
  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.hub_route_table.id
}
