# NAT GW Subnets
resource "aws_subnet" "nat_gateway" {
  count                   = local.number_of_subnets
  vpc_id                  = aws_vpc.main.id
  availability_zone       = data.aws_availability_zones.available.names[count.index]
  cidr_block              = cidrsubnet(local.vpc_cidr, 3, count.index)
  map_public_ip_on_launch = false
  tags = {
    Name = "main-vpc/${data.aws_availability_zones.available.names[count.index]}/nat-gw-subnet"
  }
}

# AWS Network Firewall Subnets
resource "aws_subnet" "network_firewall" {
  count             = local.number_of_subnets
  vpc_id            = aws_vpc.main.id
  availability_zone = data.aws_availability_zones.available.names[count.index]
  cidr_block        = cidrsubnet(local.vpc_cidr, 3, count.index + 2)

  tags = {
    Name = "main-vpc/${data.aws_availability_zones.available.names[count.index]}/network-firewall-subnet"
  }
}

# AWS TGW Subnets
resource "aws_subnet" "tgw" {
  count             = local.number_of_subnets
  vpc_id            = aws_vpc.main.id
  availability_zone = data.aws_availability_zones.available.names[count.index]
  cidr_block        = cidrsubnet(local.vpc_cidr, 3, count.index + 4)

  tags = {
    Name = "main-vpc/${data.aws_availability_zones.available.names[count.index]}/tgw-subnet"
  }
}
