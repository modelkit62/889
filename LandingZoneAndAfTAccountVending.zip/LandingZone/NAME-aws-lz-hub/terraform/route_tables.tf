# The Network Firewall Subnet Route Table to NAT Gateway for outbound traffic and to the TGW for internal traffic
resource "aws_route_table" "firewall_subnet_route_table" {
  count  = local.deploy_to_subnets
  vpc_id = aws_vpc.main.id
  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.vpc_nat_gw[count.index].id
  }
  route {
    cidr_block         = local.super_cidr
    transit_gateway_id = aws_ec2_transit_gateway.tgw.id
  }
  tags = {
    Name = "main-vpc/${data.aws_availability_zones.available.names[count.index]}/network-firewall-subnet-route-table"
  }
  depends_on = [
    aws_nat_gateway.vpc_nat_gw,
    aws_ec2_transit_gateway_vpc_attachment.hub_vpc_tgw_attachment,
    aws_ec2_transit_gateway.tgw
  ]
}

# The TGW Subnet Route Table to Network Firewall
resource "aws_route_table" "tgw_subnet_route_table" {
  count  = local.deploy_to_subnets
  vpc_id = aws_vpc.main.id
  route {
    cidr_block = "0.0.0.0/0"
    # https://github.com/hashicorp/terraform-provider-aws/issues/16759

    # Use this when need to apply the AWS Network Firewall to multiple Subnets
    # vpc_endpoint_id = element([for ss in tolist(aws_networkfirewall_firewall.vpc_network_firewall.firewall_status[0].sync_states) : ss.attachment[0].endpoint_id if ss.attachment[0].subnet_id == aws_subnet.network_firewall[count.index].id], 0)

    # Use this when use an AWS Network Firewall to single Subnet
    vpc_endpoint_id = element([for ss in tolist(aws_networkfirewall_firewall.vpc_network_firewall.firewall_status[0].sync_states) : ss.attachment[0].endpoint_id if ss.attachment[0].subnet_id == aws_subnet.network_firewall[0].id], 0)
  }
  tags = {
    Name = "main-vpc/${data.aws_availability_zones.available.names[count.index]}/tgw-subnet-route-table"
  }
  depends_on = [
    aws_networkfirewall_firewall.vpc_network_firewall,
    aws_subnet.network_firewall
  ]
}

# The NAT Gateway Subnet Route Table to Internet for outbound traffic and to the Network Firewall for internal traffic
resource "aws_route_table" "public_subnet_route_table" {
  count  = local.deploy_to_subnets
  vpc_id = aws_vpc.main.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.gw.id
  }
  # This route might not be needed?
  route {
    cidr_block = local.super_cidr
    # https://github.com/hashicorp/terraform-provider-aws/issues/16759

    # Use this when need to apply the AWS Network Firewall to multiple Subnets
    # vpc_endpoint_id = element([for ss in tolist(aws_networkfirewall_firewall.vpc_network_firewall.firewall_status[0].sync_states) : ss.attachment[0].endpoint_id if ss.attachment[0].subnet_id == aws_subnet.network_firewall[count.index].id], 0)

    # Use this when use an AWS Network Firewall to single Subnet
    vpc_endpoint_id = element([for ss in tolist(aws_networkfirewall_firewall.vpc_network_firewall.firewall_status[0].sync_states) : ss.attachment[0].endpoint_id if ss.attachment[0].subnet_id == aws_subnet.network_firewall[0].id], 0)
  }
  tags = {
    Name = "main-vpc/${data.aws_availability_zones.available.names[count.index]}/public-subnet-route-table"
  }
  depends_on = [
    aws_networkfirewall_firewall.vpc_network_firewall,
    aws_subnet.network_firewall
  ]
}

# Create route table association link between the TGW subnet and TGW route table
resource "aws_route_table_association" "tgw_subnet_route_table_association" {
  count          = local.deploy_to_subnets
  route_table_id = aws_route_table.tgw_subnet_route_table[count.index].id
  subnet_id      = aws_subnet.tgw[count.index].id
}

# Create route table association link between the Firewall subnet and Firewall route table
resource "aws_route_table_association" "firewall_subnet_route_table_association" {
  count          = local.deploy_to_subnets
  route_table_id = aws_route_table.firewall_subnet_route_table[count.index].id
  subnet_id      = aws_subnet.network_firewall[count.index].id
}

# Create route table association link between the public subnet (NAT Gateway) and public route table
resource "aws_route_table_association" "public_subnet_route_table_association" {
  count          = local.deploy_to_subnets
  route_table_id = aws_route_table.public_subnet_route_table[count.index].id
  subnet_id      = aws_subnet.nat_gateway[count.index].id
}
