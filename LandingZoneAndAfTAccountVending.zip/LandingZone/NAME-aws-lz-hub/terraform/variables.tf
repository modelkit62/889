## Module Variables
variable "owner" {
  description = "Value used in naming convention"
  type        = string
  default     = "NAME"
}

variable "product" {
  description = "Value used in naming convention"
  type        = string
  default     = "aws-lz-hub"
}

variable "aws_region" {
  description = "The AWS Region"
  type        = string
  default     = "eu-west-2"
}

variable "tags" {
  description = "Common tags for all resources"
  type        = map(string)
  default = {
    Owner   = "NAME"
    Product = "NAME AWS Landing Zone"
    Project = "Networking via Terraform"
  }
}
