# Network account Deploy Role

# The Deploy role in the Network account
data "aws_iam_role" "deploy_role" {
  name = "NAME-aws-lz-networking-account-deploy-role"
}

# Creates a Inline policy on the Deploy role above. Its permissions are below.
resource "aws_iam_role_policy" "deploy_policy" {
  name   = "${local.name}-deploy-role-policy-terraform"
  role   = data.aws_iam_role.deploy_role.name
  policy = data.aws_iam_policy_document.deploy_role_policy.json
}

# Inline policy: The actions the Deploy role can execute
data "aws_iam_policy_document" "deploy_role_policy" {

  statement {
    sid    = "KMS"
    effect = "Allow"
    actions = [
      "kms:Encrypt",
      "kms:Decrypt",
      "kms:ReEncrypt*",
      "kms:GenerateDataKey*",
      "kms:DescribeKey"
    ]
    resources = ["*"]
  }

  statement {
    sid    = "ec2"
    effect = "Allow"
    actions = [
      "ec2:DescribeAddressesAttribute",
    ]
    resources = ["*"]
  }
}

# Alternative way to add Policies to the Deploy role
resource "aws_iam_role_policy_attachment" "use_managed_roles" {
  for_each = toset(
    [
      "arn:aws:iam::aws:policy/AmazonVPCFullAccess",
      "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess",
      "arn:aws:iam::aws:policy/AWSNetworkFirewallFullAccess",
      "arn:aws:iam::aws:policy/AmazonEC2FullAccess",
      "arn:aws:iam::aws:policy/AWSResourceAccessManagerFullAccess",
    ]
  )
  role       = data.aws_iam_role.deploy_role.name
  policy_arn = each.key
}

# VPC Flow Logs Role

data "aws_iam_policy_document" "vpc_flow_logs_assume_role" {
  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["vpc-flow-logs.amazonaws.com"]
    }

    actions = ["sts:AssumeRole"]
  }
}

resource "aws_iam_role" "vpc_flow_logs_role" {
  name               = "NAME-aws-lz-networking-account-vpc-flow-logs-role"
  assume_role_policy = data.aws_iam_policy_document.vpc_flow_logs_assume_role.json
}

data "aws_iam_policy_document" "vpc_flow_logs_policy" {
  statement {
    effect = "Allow"
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:DescribeLogGroups",
      "logs:DescribeLogStreams",
    ]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "flow_logs" {
  name   = "${local.name}-vpc-flow-logs-role-policy"
  role   = aws_iam_role.vpc_flow_logs_role.id
  policy = data.aws_iam_policy_document.vpc_flow_logs_policy.json
}
