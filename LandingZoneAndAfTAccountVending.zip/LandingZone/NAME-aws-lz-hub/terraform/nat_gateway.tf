resource "aws_nat_gateway" "vpc_nat_gw" {
  count         = 1
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.nat_gateway[count.index].id
  tags = {
    Name = "main-vpc/${data.aws_availability_zones.available.names[count.index]}/nat-gateway"
  }
  depends_on = [
    aws_internet_gateway.gw,
    aws_subnet.nat_gateway
  ]
}

# Elastic IP for NAT Gateway
resource "aws_eip" "nat" {
  domain     = "vpc"
  depends_on = [aws_internet_gateway.gw]
}
