# vpc_endpoints = []
# domain_allow_list = []
# domain_block_list = ["example.com"]
