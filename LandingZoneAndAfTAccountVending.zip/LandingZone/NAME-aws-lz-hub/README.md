# NAME AWS Landing Zone Hub

This Terraform repository is an alternative networking implementation via Terraform rather than using the AWS LZ built in functionality. It creates a network egress solution to connect multiple workload accounts via AWS TGW to a centralised egress to the internet.

This repository contains AWS Networking resources defined in Terraform for Workload OU nested AWS accounts that are part of the NAME AWS Landing Zone (LZ).

## Pre-Req's

* In Terminal ensure terraform, aws and git tools are installed.
* The following have already been created:
    1. The NAME AWS LZ
    2. The Infrastructure OU via the LZ
    3. The Networking account in the Infrastructure OU via the LZ
* Have Admin permissions in the Network account.

### AWS S3 Bucket

* Either run the below AWS commands in the Network account via CloudShell or obtain AWS credentials from the SSO page and run them locally.
* Create the AWS S3 Bucket table using these commands:

```
aws s3api create-bucket --bucket NAME-aws-lz-hub-tfstate --create-bucket-configuration LocationConstraint=eu-west-2
```
```
aws s3api put-bucket-versioning --bucket NAME-aws-lz-hub-tfstate --versioning-configuration Status=Enabled
```
* The first Terraform apply will add the statefile to the AWS S3 bucket.
* Check the AWS S3 Bucket is created succesfully in the Networking account.

### IAM Role

* Create a AWS OIDC so that the GitHub Actions `configure-aws-credentials` action will receive a JWT from the GitHub OIDC when the CI is executed. Follow these steps:

    1. Download the AWS CloudFormation [template](https://d38mtn6aq9zhn6.cloudfront.net/configure-aws-credentials-latest.yml) from the AWS GitHub repository.
    2. Log into the account and create a new AWS CloudFormation stack using the downloaded template file. The Stack will create a new IAM Role and a new AWS IAM Identity provider in the account for the GitHub Identity provider. Provide an IAM Role name called `NAME-aws-lz-networking-account-deploy-role`, the NAME GitHub Organisation name and NAME Repository name details into the Stack form, and leave the other settings as default.
    3. Create and run the Stack.
    4. Open the Stack results to see that the new IAM Role and a new AWS IAM Identity provider resources were created.

    OR

    1. Create an AWS IAM Identity Provider in the AWS account, copy the output for use in Step 2:
    ```
    aws iam create-open-id-connect-provider --url https://token.actions.githubusercontent.com --client-id-list sts.amazonaws.com --thumbprint-list ffffffffffffffffffffffffffffffffffffffff
    ```
    2. Create a new AWS IAM Role, called `NAME-aws-lz-networking-account-deploy-role`, that uses the Trust Policy from this [site](https://github.com/aws-actions/configure-aws-credentials?tab=readme-ov-file#quick-start-oidc-recommended). Update the Trust Policy to use the NAME GitHub Organisation name, the GitHub repository, use the AWS IAM Identity Provider value from Step 1 and change the branch to main.

* Create and add an AWS IAM Policy that will allow the AWS IAM Role to connect to AWS S3 in order to access the Terraform statefile when run the GitHub Actions. 

    1. Go to AWS IAM and create a new Policy, called `NAME-aws-lz-networking-account-deploy-role-policy` use the example from this [website](https://developer.hashicorp.com/terraform/language/backend/s3#s3-bucket-permissions) and apply the bucket arn, bucket name and object name. Then attach the policy to the IAM role.

    2. Create and add second AWS IAM Policy that allows the Terraform code to update the AWS IAM Role with its own AWS IAM policies that are specific to the Terraform deployment. Name the IAM Policy `NAME-aws-lz-networking-account-deploy-role-iam-policy`, use the below Policy and update the AWS account number. Then attach the policy to the IAM role.

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "iam:GetRole",
                "iam:UpdateRole",
                "iam:PutRolePolicy",
                "iam:GetRolePolicy",
                "iam:DeleteRolePolicy",
                "iam:AttachRolePolicy",
                "iam:ListAttachedRolePolicies",
                "iam:DetachRolePolicy",
                "iam:CreateRole",
                "iam:DeleteRole",
                "iam:TagRole",
                "iam:ListRolePolicies",
                "iam:ListInstanceProfilesForRole",
                "iam:PassRole"
            ],
            "Resource": "arn:aws:iam::NETWORK-ACCOUNT-ID:role/NAME-aws-*"
        }
    ]
}
```
* After the above IAM Role is created, copy the IAM Role arn and use it in the GitHub action `configure-aws-credentials` role to be assumed.
* Go to the `guardrails-3.json` file in the [NAME_aws_landing_zone_configuration](https://github.com/NAME/NAME_aws_landing_zone_configuration/blob/main/service-control-policies/guardrails-3.json) and add the IAM Role arn to the list of IAM policies under the `"aws:PrincipalARN"` section.
* Add the name of the AWS S3 Bucket to the `terraform/backend.tf` file.
* Obtain AWS credentials for the Network account from the SSO page to run the Terraform commands below locally and check the Terraform commands work correctly.
* Create the Terraform state file and lock file in the AWS S3 Bucket:

```
aws sts get-caller-identity
```
```
cd terraform
```
```
terraform init
```
```
terraform plan
```
```
terraform apply
```
* At this point the Terraform statefile and lock should exist in the AWS S3 Bucket.
* If see a **Terraform statefile lock issue**. Copy the ID from the message and use the following command to unlock the file `terraform force-unlock ID`.

## Deployment

* Changes applied to the main branch will be deployed to the Networking account via the GitHub Actions in this repository. See the `.github/workflows` folder.

* At run time on GitHub Actions the CI/CD will assume the Network account IAM Role called `GitHub_to_AWS_via_FederatedOIDC_NAME_LZ_Hub`. The role follows least privilege access which means all IAM Policy permissions need be added to the IAM Role via `terraform/iam.tf` file in order to interact with the AWS resources correctly.

* Ensure **main branch protection** is applied on this repository to prevent commits directly to the main branch.

* If the **GitHub Action fails** due to adding a new IAM policy, re-run the failed job, on the next iteration it will assume the IAM role again with the new IAM policy changes applied.

### Tips

* When re-deploying the configuration the CloudWatch log group from a previous deployment may still exist and prevent a successful Terraform Apply. Manually delete the CloudWatch log groups contained in the cloudwatch.tf file.

## Local Development

* It will be possible to run the Terraform locally if you have admin access to the Network account by using the AWS credentials from the SSO page.

* There is a AWS Control Tower SCP that protects the Network AWS Resources. It might prevent changes unless you use the `NAME-aws-lz-networking-account-deploy-role`.

* To use the correct Terraform version specified by the repository use the `tfswitch` tool if required.
