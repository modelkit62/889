# The Lambda Subnet Route Table to TGW
resource "aws_route_table" "lambda_subnet_route_table" {
  for_each = local.subnets

  vpc_id = aws_vpc.main.id
  route {
    cidr_block         = "0.0.0.0/0"
    transit_gateway_id = data.aws_ec2_transit_gateway.hub.id
  }
  tags = {
    Name = "${local.name}-vpc/${data.aws_availability_zones.available.names[each.value]}/lambda-subnet-route-table"
  }
}

# Create route table association link between the Lambda subnet and TGW route table
resource "aws_route_table_association" "lambda_subnet_route_table_association" {
  for_each = local.subnets

  route_table_id = aws_route_table.lambda_subnet_route_table[each.key].id
  subnet_id      = aws_subnet.lambdas[each.key].id
}
