# Lambda Subnets
resource "aws_subnet" "lambdas" {
  for_each = local.subnets

  vpc_id            = aws_vpc.main.id
  availability_zone = data.aws_availability_zones.available.names[each.value]
  cidr_block        = cidrsubnet(var.vpc_cidr, 3, each.value)
  tags = {
    Name = "${local.name}-vpc/${data.aws_availability_zones.available.names[each.value]}/lambda-subnet"
  }
}

# AWS Aurora Subnets
resource "aws_subnet" "aurora" {
  for_each = local.aurora_subnets

  vpc_id            = aws_vpc.main.id
  availability_zone = data.aws_availability_zones.available.names[each.value]
  cidr_block        = cidrsubnet(var.vpc_cidr, 3, each.value + 2)
  tags = {
    Name = "${local.name}-vpc/${data.aws_availability_zones.available.names[each.value]}/aurora-subnet"
  }
}

resource "aws_db_subnet_group" "aurora" {
  name       = "${local.name}-aurora-subnet-group"
  subnet_ids = [for subnet in aws_subnet.aurora : subnet.id]
}

# AWS TGW Subnets
resource "aws_subnet" "tgw" {
  for_each = local.subnets

  vpc_id            = aws_vpc.main.id
  availability_zone = data.aws_availability_zones.available.names[each.value]
  cidr_block        = cidrsubnet(var.vpc_cidr, 3, each.value + 5)

  tags = {
    Name = "${local.name}-vpc/${data.aws_availability_zones.available.names[each.value]}/tgw-subnet"
  }
}

# Endpoint Subnets
resource "aws_subnet" "endpoint" {
  for_each = local.subnets

  vpc_id            = aws_vpc.main.id
  availability_zone = data.aws_availability_zones.available.names[each.value]
  cidr_block        = cidrsubnet(var.vpc_cidr, 3, each.value + 7)
  tags = {
    Name = "${local.name}-vpc/${data.aws_availability_zones.available.names[each.value]}/endpoint-subnet"
  }
}
