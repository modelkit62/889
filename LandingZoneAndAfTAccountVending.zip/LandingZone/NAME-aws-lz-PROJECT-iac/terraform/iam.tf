# NAME AWS account Deploy Role

# The Deploy role in the AWS account
data "aws_iam_role" "deploy_role" {
  name = "${local.name}-account-deploy-role"
}

# Creates an Inline policy on the Deploy role above. Its permissions are below.
resource "aws_iam_role_policy" "deploy_policy" {
  name   = "${local.name}-deploy-role-policy-terraform"
  role   = data.aws_iam_role.deploy_role.name
  policy = data.aws_iam_policy_document.deploy_role_policy.json
}

# Inline policy: The actions the Deploy role can execute
data "aws_iam_policy_document" "deploy_role_policy" {

  statement {
    sid    = "KMS"
    effect = "Allow"
    actions = [
      "kms:Encrypt",
      "kms:Decrypt",
      "kms:ReEncrypt*",
      "kms:GenerateDataKey*",
      "kms:DescribeKey"
    ]
    resources = ["*"]
  }

  statement {
    sid    = "ec2"
    effect = "Allow"
    actions = [
      "ec2:DescribeAddressesAttribute",
    ]
    resources = ["*"]
  }
}

# Alternative way to add Policies to the Deploy role
resource "aws_iam_role_policy_attachment" "use_managed_roles" {
  for_each = toset(
    [
      "arn:aws:iam::aws:policy/AmazonVPCFullAccess",
      "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess",
      "arn:aws:iam::aws:policy/AmazonEC2FullAccess",
      "arn:aws:iam::aws:policy/AmazonRDSFullAccess",
    ]
  )
  role       = data.aws_iam_role.deploy_role.name
  policy_arn = each.key
}

# VPC Flow Logs Role

data "aws_iam_policy_document" "vpc_flow_logs_assume_role" {
  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["vpc-flow-logs.amazonaws.com"]
    }

    actions = ["sts:AssumeRole"]
  }
}

resource "aws_iam_role" "vpc_flow_logs_role" {
  name               = "${local.name}-vpc-flow-logs-role"
  assume_role_policy = data.aws_iam_policy_document.vpc_flow_logs_assume_role.json
}

data "aws_iam_policy_document" "vpc_flow_logs_policy" {
  statement {
    effect = "Allow"
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:DescribeLogGroups",
      "logs:DescribeLogStreams",
    ]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "flow_logs" {
  name   = "${local.name}-vpc-flow-logs-role-policy"
  role   = aws_iam_role.vpc_flow_logs_role.id
  policy = data.aws_iam_policy_document.vpc_flow_logs_policy.json
}


# This is for CloudFront CDN to access the S3 bucket for the static hosted website
data "aws_iam_policy_document" "s3_static_website_bucket_policy" {
  statement {
    sid     = "AllowCloudFrontServicePrincipalRead"
    actions = ["s3:GetObject"]
    resources = [
      "${aws_s3_bucket.website.arn}/*",
    ]
    principals {
      type        = "Service"
      identifiers = ["cloudfront.amazonaws.com"]
    }
    condition {
      test     = "StringLike"
      variable = "AWS:SourceArn"

      values = [
        aws_cloudfront_distribution.static_website_distribution.arn
      ]
    }
  }
  depends_on = [
    aws_s3_bucket.website
  ]
}

# This is for Application to access the S3 bucket for student submissions
data "aws_iam_policy_document" "s3_student_submissions_bucket_policy" {
  statement {
    actions = ["s3:PutObject"]
    resources = [
      "${aws_s3_bucket.student_submissions.arn}/*",
    ]
    principals {
      type        = "AWS"
      identifiers = [aws_iam_role.processor_lambda.arn]
    }
  }
}

# GH Actions Deploy UI Code IAM Deploy Role

# This is used to deploy the front end code from the GH repository using a GH Action to AWS.

# # This is the IAM role so that GH Action can deploy the UI code from the repo to the S3 bucket
# resource "aws_iam_role" "ui_code_deploy_role" {
#   name                 = "${local.name}-ui-code-deploy-role"
#   assume_role_policy   = data.aws_iam_policy_document.ui_code_deploy_assume_role.json
#   description          = "The IAM role used to push the UI code from GitHub repo to S3 using GitHub Actions"
#   max_session_duration = 3600
#   path                 = "/github-deploy-roles/"
# }

# # The STS assume role for the UI code deploy role
# data "aws_iam_policy_document" "ui_code_deploy_assume_role" {
#   statement {
#     effect = "Allow"
#     actions = [
#       "sts:AssumeRoleWithWebIdentity",
#       "sts:TagSession"
#     ]
#     principals {
#       type = "Federated"
#       identifiers = [
#         "arn:aws:iam::${data.aws_caller_identity.current.account_id}:oidc-provider/token.actions.githubusercontent.com"
#       ]
#     }

#     condition {
#       test     = "StringEquals"
#       variable = "token.actions.githubusercontent.com:aud"
#       values   = ["sts.amazonaws.com"]
#     }

#     dynamic "condition" {
#       for_each = var.ui_code_deploy_role_conditions

#       content {
#         test     = condition.value.test
#         variable = condition.value.variable
#         values   = condition.value.values
#       }
#     }
#   }
# }

# # Link the Deploy role with the actions it can execute
# resource "aws_iam_role_policy" "ui_code_deploy_policy" {
#   name   = "${local.name}-ui-code-deploy-policy"
#   role   = aws_iam_role.ui_code_deploy_role.name
#   policy = data.aws_iam_policy_document.ui_code_deploy_iam_statements.json
# }

# # The actions the UI code deploy role can execute
# data "aws_iam_policy_document" "ui_code_deploy_iam_statements" {

#   statement {
#     sid    = "AllowBucketList"
#     effect = "Allow"
#     actions = [
#       "s3:ListBucket",
#     ]
#     resources = [
#       aws_s3_bucket.arn
#     ]
#   }

#   statement {
#     sid    = "AllowBucketOps"
#     effect = "Allow"
#     actions = [
#       "s3:PutObject",
#       "s3:PutObjectAcl",
#       "s3:DeleteObject",
#     ]
#     resources = [
#       "${aws_s3_bucket.arn}/*"
#     ]
#   }
# }


# Lambda Roles

# The STS assume role for the Lambda roles
data "aws_iam_policy_document" "lambda_assume_role" {
  statement {
    effect = "Allow"
    actions = [
      "sts:AssumeRole",
    ]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

# The Lambda role for the Processor Lambda
resource "aws_iam_role" "processor_lambda" {
  name                 = "${local.name}-processor-lambda-role"
  assume_role_policy   = data.aws_iam_policy_document.lambda_assume_role.json
  description          = "Role used by the Processor Lambda"
  max_session_duration = 3600
  path                 = "/lambda-roles/"
}

# Processor Lambda Policy
resource "aws_iam_role_policy_attachment" "lambda0_managed_roles" {
  role       = aws_iam_role.lambda1.name
  policy_arn = each.key
  for_each = toset(
    [
      "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
      "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
    ]
  )
}

# The Lambda role for the Peer Review Lambda
resource "aws_iam_role" "lambda1" {
  name                 = "${local.name}-lambda0-lambda-role"
  assume_role_policy   = data.aws_iam_policy_document.lambda_assume_role.json
  description          = "Role used by the Peer Review Lambda"
  max_session_duration = 3600
  path                 = "/lambda-roles/"
}

# Peer Review Lambda Policy
resource "aws_iam_role_policy_attachment" "lambda1_managed_roles" {
  role       = aws_iam_role.lambda1.name
  policy_arn = each.key
  for_each = toset(
    [
      "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
      "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
    ]
  )
}

# The Lambda role for the Authentication Lambda
resource "aws_iam_role" "authentication_lambda" {
  name                 = "${local.name}-authenicate-lambda-role"
  assume_role_policy   = data.aws_iam_policy_document.lambda_assume_role.json
  description          = "Role used by the Authentication Lambda"
  max_session_duration = 3600
  path                 = "/lambda-roles/"
}

# Authentication Lambda Policy
resource "aws_iam_role_policy_attachment" "authentication_lambda_managed_roles" {
  role       = aws_iam_role.authentication_lambda.name
  policy_arn = each.key
  for_each = toset(
    [
      "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
      "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
    ]
  )
}

# The Lambda role for the API Lambda
resource "aws_iam_role" "api_lambda" {
  name                 = "${local.name}-api-lambda-role"
  assume_role_policy   = data.aws_iam_policy_document.lambda_assume_role.json
  description          = "Role used by the API Lambda"
  max_session_duration = 3600
  path                 = "/lambda-roles/"
}

# API Lambda Policy
resource "aws_iam_role_policy_attachment" "api_lambda_managed_roles" {
  role       = aws_iam_role.api_lambda.name
  policy_arn = each.key
  for_each = toset(
    [
      "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
      "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
    ]
  )
}

# # Creates an Inline policy on the peer review Lambda above. Its permissions are below.
# resource "aws_iam_role_policy" "peer_review_lamba_inline_policy" {
#   name   = "${local.name}-lambda0-lambda-policy-terraform"
#   role   = data.aws_iam_role.lambda1.name
#   policy = data.aws_iam_policy_document.peer_review_lamba_policy.json
# }

# # Lambda extra policy for peer review Lambda 
# data "aws_iam_policy_document" "peer_review_lamba_policy" {

#   statement {
#     sid    = "DynamoDBAppAccess"
#     effect = "Allow"
#     actions = [
#       "dynamodb:GetItem",
#       "dynamodb:PutItem",
#       "dynamodb:UpdateItem",
#       "dynamodb:DeleteItem",
#       "dynamodb:Scan",
#       "dynamodb:Query"
#     ]
#     resources = aws_dynamodb_table.app_table.arn
#   }
# }

# # Creates an Inline policy on the processor Lambda above. Its permissions are below.
# resource "aws_iam_role_policy" "processor_lamba_inline_policy" {
#   name   = "${local.name}-processor-lambda-policy-terraform"
#   role   = data.aws_iam_role.processor_lambda.name
#   policy = data.aws_iam_policy_document.processor_lamba_policy.json
# }

# # processor lambda extra policy
# data "aws_iam_policy_document" "processor_lamba_policy" {

#   statement {
#     sid    = "S3AppAccess"
#     effect = "Allow"
#     actions = [
#       "s3:?",
#     ]
#     resources = S3 bucket ?
#   }
# }
