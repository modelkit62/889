# Also creates a default security group, default NACL, default route table + route.
# Route table can be replace if use aws_main_route_table_association.
resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  tags                 = { "Name" = "${local.name}-vpc" }
}
