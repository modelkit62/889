resource "aws_ecr_repository" "lambda_ecr_repo" {
  for_each             = local.lambda_functions
  name                 = each.value.ecr_name
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }
}
