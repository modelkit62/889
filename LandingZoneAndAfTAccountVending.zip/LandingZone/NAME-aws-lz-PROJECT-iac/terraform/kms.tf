# Use the existing accelerator kms cloudwatch key
data "aws_kms_key" "accelerator_cloudwatch_key" {
  key_id = "alias/accelerator/kms/cloudwatch/key"
}
