# TODO: Add gateway endpoints
# TODO: delete these endpoints

resource "aws_vpc_endpoint" "ssm_endpoint" {
  vpc_id            = aws_vpc.main.id
  service_name      = "com.amazonaws.${data.aws_region.current.region}.ssm"
  vpc_endpoint_type = "Interface"
  subnet_ids        = [for subnet in aws_subnet.lambdas : subnet.id]
  security_group_ids = [
    aws_security_group.endpoint_sg.id,
  ]
  private_dns_enabled = true
  tags = {
    "Name" = "ssm_endpoint"
  }
}

resource "aws_vpc_endpoint" "ssm_messages_endpoint" {
  vpc_id            = aws_vpc.main.id
  service_name      = "com.amazonaws.${data.aws_region.current.region}.ssmmessages"
  vpc_endpoint_type = "Interface"
  subnet_ids        = [for subnet in aws_subnet.lambdas : subnet.id]
  security_group_ids = [
    aws_security_group.endpoint_sg.id,
  ]
  private_dns_enabled = true
  tags = {
    "Name" = "ssm_messages_endpoint"
  }
}

resource "aws_vpc_endpoint" "ec2_messages_endpoint" {
  vpc_id            = aws_vpc.main.id
  service_name      = "com.amazonaws.${data.aws_region.current.region}.ec2messages"
  vpc_endpoint_type = "Interface"
  subnet_ids        = [for subnet in aws_subnet.lambdas : subnet.id]
  security_group_ids = [
    aws_security_group.endpoint_sg.id,
  ]
  private_dns_enabled = true
  tags = {
    "Name" = "ec2_messages_endpoint"
  }
}

data "aws_region" "current" {}
