resource "aws_security_group" "lambda_sg" {
  name        = "lambda-http-https-sg"
  description = "Allow HTTP and HTTPS ingress and egress"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "Allow HTTP from Hub VPC only"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = [local.hub_cidr]
  }

  ingress {
    description = "Allow HTTPS from Hub VPC only"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [local.hub_cidr]
  }

  # TODO: delete
  ingress {
    description = "Allow HTTPS for AWS Systems Manager"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow all traffic inside VPC"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = [var.vpc_cidr]
  }

  egress {
    description = "Allow all traffic outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# TODO: delete
resource "aws_security_group" "endpoint_sg" {
  name        = "ssm-ec2-endpoints-sg"
  description = "Allow TLS inbound traffic for SSM/EC2 endpoints"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "TLS from VPC"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }
  tags = {
    Name = "sg-ssm-ec2-endpoints"
  }
}
