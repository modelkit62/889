resource "aws_cloudfront_origin_access_control" "default" {
  name                              = "${local.name}-cloudfront-origin-access-control"
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}

resource "aws_cloudfront_distribution" "static_website_distribution" {
  origin {
    # domain_name = "${aws_s3_bucket.website.bucket}.s3-website-${var.aws_region}.amazonaws.com"
    domain_name              = aws_s3_bucket.website.bucket_regional_domain_name
    origin_id                = aws_s3_bucket.website.id
    origin_access_control_id = aws_cloudfront_origin_access_control.default.id
  }

  tags = {
    Name = "${local.name}-cloudfront-distribution"
  }

  enabled             = true
  is_ipv6_enabled     = true
  comment             = "Static website distribution"
  default_root_object = "index.html"
  price_class         = "PriceClass_All" # PriceClass_All, PriceClass_200, PriceClass_100

  # Optional: Alternative domain name, Either a CNAME record or example.com in var.domain
  # This is good for Subject Alternative Names (SANS)
  # aliases = [var.domain] 
  # aliases = concat([local.domain], local.domain_sans)
  # aliases = ["mysite.example.com", "yoursite.example.com"]

  default_cache_behavior {
    allowed_methods        = ["GET", "HEAD"] # "HEAD", "OPTIONS", "PATCH", "POST", "PUT"
    cached_methods         = ["GET", "HEAD"]
    target_origin_id       = aws_s3_bucket.website.id
    min_ttl                = 0
    default_ttl            = 3600
    max_ttl                = 86400
    compress               = true
    viewer_protocol_policy = "redirect-to-https" # allow-all, https-only, or redirect-to-https

    forwarded_values {
      query_string = false
      cookies {
        forward = "none"
      }
    }
  }

  restrictions {
    geo_restriction {
      restriction_type = "none" # none, whitelist, or blacklist
      # locations        = ["US", "CA", "GB", "DE"]
    }
  }

  viewer_certificate {
    cloudfront_default_certificate = true
  }

  #   logging_config {
  #     include_cookies = false
  #     bucket          = "mylogs.s3.amazonaws.com"
  #     prefix          = "myprefix"
  #   }
}
