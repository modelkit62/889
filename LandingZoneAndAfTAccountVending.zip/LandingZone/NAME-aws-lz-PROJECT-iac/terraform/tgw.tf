data "aws_ec2_transit_gateway" "hub" {
  id = "tgw-?"
}

# Create a TGW attachment to connect to the TGW
resource "aws_ec2_transit_gateway_vpc_attachment" "NAME_vpc_tgw_attachment" {
  subnet_ids             = [for subnet in aws_subnet.endpoint : subnet.id]
  transit_gateway_id     = data.aws_ec2_transit_gateway.hub.id
  vpc_id                 = aws_vpc.main.id
  appliance_mode_support = "enable"
  tags = {
    Name = "${local.name}-vpc-tgw-attachment"
  }
}
