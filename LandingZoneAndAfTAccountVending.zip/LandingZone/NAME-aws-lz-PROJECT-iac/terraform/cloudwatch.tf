resource "aws_cloudwatch_log_group" "vpc_flow_logs" {
  name              = "/aws/vpc/NAME-${local.environment}-vpc-flow-logs"
  retention_in_days = 3653
  kms_key_id        = data.aws_kms_key.accelerator_cloudwatch_key.arn
  skip_destroy      = false
}

# resource "aws_cloudwatch_log_group" "lambda_logs" {
#   for_each = local.lambda_functions

#   name              = "/aws/lambda/${each.key}-logs"
#   retention_in_days = 3653
#   kms_key_id        = data.aws_kms_key.accelerator_cloudwatch_key.arn
#   skip_destroy      = false
# }
