# resource "aws_lambda_function" "lambdas" {
#   for_each = local.lambda_functions

#   function_name = each.key
#   role          = each.value.role
#   description   = each.value.description
#   timeout       = each.value.timeout
#   memory_size   = each.value.memory
#   architectures = ["arm64"] # or x86_64

#   # Use this for 
#   runtime          = "nodejs20.x"
#   handler          = "index.handler"
#   filename         = "${path.module}/../build/function.zip"
#   source_code_hash = filebase64sha256("${path.module}/../build/function.zip")

#   # TODO: Use ECR image when created
#   # package_type  = "Image"
#   # image_uri     = "${aws_ecr_repository.lambda_ecr_repo[each.key].repository_url}:${each.value.lambda_version}"
#   # image_config {
#   #   entry_point = [each.value.entry_point]
#   #   command     = [each.value.command]
#   # }

#   vpc_config {
#     subnet_ids         = [for i in range(local.is_prod == true ? local.prod_env_number_of_subnets : local.test_env_number_of_subnets) : aws_subnet.lambdas[i].id]
#     security_group_ids = [aws_security_group.lambda_sg.id]
#   }

#   logging_config {
#     log_format            = "JSON"
#     application_log_level = "INFO"
#     system_log_level      = "WARN"
#   }
# }

# data "archive_file" "artifact" {
#   type        = "zip"
#   source_dir  = "${path.module}/../hello-world"
#   output_path = "${path.module}/../hello-world.zip"
# }

# # Create alias of Lambda that uses a specifc Lambda version
# # Use this for accessing the Lambda indirectly
# resource "aws_lambda_alias" "example" {
#   for_each = local.lambda_functions

#   name             = each.key
#   description      = "The ${each.value.description} alias"
#   function_name    = aws_lambda_function.lambdas[each.key].function_name
#   function_version = each.value.alias_version
# }


# resource "aws_lambda_event_source_mapping" "example" {
#   event_source_arn  = aws_dynamodb_table.example.stream_arn
#   function_name     = aws_lambda_function.lambdas[each.key].function_name
#   starting_position = "LATEST"

#   tags = {
#     Name = "dynamodb-stream-mapping"
#   }
# }

# resource "aws_lambda_permission" "allow_access" {
#   function_name = aws_lambda_function.main.function_name
#   statement_id  = "AllowInvokeFrom?"
#   action        = "lambda:InvokeFunction"
#   principal     = 
#   source_arn    = 
# }
