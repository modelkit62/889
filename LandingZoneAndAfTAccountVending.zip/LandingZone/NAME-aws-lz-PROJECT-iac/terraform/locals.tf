locals {

  envs = {
    "test"    = "test"
    "prod"    = "prod"
    "default" = "test"
  }
  environment = local.envs[var.environment]

  subnets = {
    for i in range(var.number_of_subnets) : "subnet-${i}" => i
  }

  aurora_subnets = {
    for i in range(var.number_of_aurora_subnets) : "aurora-subnet-${i}" => i
  }

  lambda_functions = {
    "${local.name}-lambda0-lambda" = {
      description    = "The lambda1 Lambda"
      timeout        = var.lambda_timeout
      memory         = var.lambda_memory
      role           = aws_iam_role.lambda1_lambda.arn
      lambda_version = local.lambda1_version
      entry_point    = "/lambda-entrypoint.sh"
      command        = "app.handler"
      alias_version  = trimspace(local.environment) == "dev" ? "$LATEST" : "1"
      ecr_name       = "${local.name}-lambda0-lambda"
    },
    "${local.name}-lambda0-lambda" = {
      description    = "The ? Lambda"
      timeout        = var.lambda_timeout
      memory         = var.lambda_memory
      role           = aws_iam_role.lambda1.arn
      lambda_version = local.lambda1_version
      entry_point    = "/lambda-entrypoint.sh"
      command        = "app.handler"
      alias_version  = trimspace(local.environment) == "dev" ? "$LATEST" : "1"
      ecr_name       = "${local.name}-lambda0-lambda"
    },
    # If need to authenicate a new request in code or API Gateway auth lambda
    "${local.name}-authenicate-lambda" = {
      description    = "The authenicate Lambda"
      timeout        = var.lambda_timeout
      memory         = var.lambda_memory
      role           = aws_iam_role.authentication_lambda.arn
      lambda_version = local.lambda2_version
      entry_point    = "/lambda-entrypoint.sh"
      command        = "app.handler"
      alias_version  = trimspace(local.environment) == "dev" ? "$LATEST" : "1"
      ecr_name       = "${local.name}-authenicate-lambda"
    },
    # If use API Gateway
    "${local.name}-api-endpoint-lambda" = {
      description    = "The API Lambda"
      timeout        = var.lambda_timeout
      memory         = var.lambda_memory
      role           = aws_iam_role.api_lambda.arn
      lambda_version = local.lambda3_version
      entry_point    = "/lambda-entrypoint.sh"
      command        = "app.handler"
      alias_version  = trimspace(local.environment) == "dev" ? "$LATEST" : "1"
      ecr_name       = "${local.name}-api-endpoint-lambda"
    },
  }


  # Use either the above versions on the Lambda's or a specific version via the override variable value
  # 1. Remove leading/trailing whitespace from variable
  # 2. If override variable is provided use that value
  # 3. Else use the above released version
  lambda0_version = trimspace(var.lambda0_version_override) != "" ? var.lambda0_version_override : var.lambda0_released_version
  lambda1_version = trimspace(var.lambda1_version_override) != "" ? var.lambda1_version_override : var.lambda1_released_version
  lambda2_version = trimspace(var.lambda2_version_override) != "" ? var.lambda2_version_override : var.lambda2_released_version
  lambda3_version = trimspace(var.lambda3_version_override) != "" ? var.lambda3_version_override : var.lambda3_released_version

  # Naming conventions
  # prefix = "/${var.owner}/${var.product}/${local.environment}"
  name = "${var.owner}-${var.product}-${local.environment}"

  # Tags
  default_tags = {
    Owner       = "NAME"
    Product     = "NAME"
    Environment = local.environment
  }

  # Network
  hub_cidr = "10.100.0.0/24"

}

# Used to get the AWS account number
# data "aws_caller_identity" "current" {}
