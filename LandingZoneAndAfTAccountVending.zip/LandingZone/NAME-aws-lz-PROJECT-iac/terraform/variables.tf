## Module Variables
variable "owner" {
  description = "Value added in naming convention"
  type        = string
  default     = "NAME"
}

variable "product" {
  description = "Value added in naming convention"
  type        = string
  default     = "NAME"
}

variable "aws_region" {
  description = "The AWS region"
  type        = string
  default     = "eu-west-2"
}

variable "environment" {
  type    = string
  default = "test"
}

variable "number_of_subnets" {
  description = "number of subnets per env"
  type        = number
  default     = 1
}

variable "number_of_aurora_subnets" {
  description = "number of subnets per env for Aurora"
  type        = number
  default     = 2
}

variable "vpc_cidr" {
  description = "cidr range per env"
  type        = string
}

# variable "log_retention" {
#   description = "number of days to store logs"
#   type        = number
#   default     = 30
# }

# variable "api_id" {
#   description = "The ID of the API Gateway."
#   type        = string
# }

variable "lambda_timeout" {
  description = "Lambda timeout value"
  type        = number
  default     = 25
}

variable "lambda_memory" {
  description = "Lambda memory value"
  type        = number
  default     = 128
}

variable "lambda0_version_override" {
  description = "Override the Lambda version to use in deployment"
  type        = string
  default     = ""
}

variable "lambda1_version_override" {
  description = "Override the Lambda version to use in deployment"
  type        = string
  default     = ""
}

variable "lambda2_version_override" {
  description = "Override the Lambda version to use in deployment"
  type        = string
  default     = ""
}

variable "lambda3_version_override" {
  description = "Override the Lambda version to use in deployment"
  type        = string
  default     = ""
}

variable "lambda0_released_version" {
  description = "Lambda version to use in deployment"
  type        = string
  default     = ""
}

variable "lambda1_released_version" {
  description = "Lambda version to use in deployment"
  type        = string
  default     = ""
}

variable "lambda2_released_version" {
  description = "Lambda version to use in deployment"
  type        = string
  default     = ""
}

variable "lambda3_released_version" {
  description = "Lambda version to use in deployment"
  type        = string
  default     = ""
}

# variable "deploy_role_trusted_principles" {
#   description = "The principles that are allowed to assume the Deploy role"
#   type        = list(string)
#   default = [
#     "arn:aws:iam::XXXXXX:role/${var.owner}-instance-role",
#   ]
# }

# variable "ui_code_deploy_role_conditions" {
#   description = "The repository that can deploy the UI code to AWS"
#   type        = list(object({ test = string, variable = string, values = list(string) }))
#   default = [{
#     test     = "StringLike"
#     variable = "token.actions.githubusercontent.com:sub"
#     values   = ["repo:NAME/REPO-NAME:*"]
#   }]
# }
