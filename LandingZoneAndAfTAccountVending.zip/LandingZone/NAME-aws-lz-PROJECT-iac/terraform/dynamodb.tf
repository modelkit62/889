# resource "aws_dynamodb_table" "app_table" {
#   name           = "${local.name}-table"
#   billing_mode   = "PAY_PER_REQUEST"  # or "PROVISIONED"
#   hash_key       = "id"

#   attribute {
#     name = "id"
#     type = "S"
#   }
# }
