number_of_subnets        = 1
number_of_aurora_subnets = 2
vpc_cidr                 = "10.101.0.0/24"

# Released Lambda code versions
lambda0_released_version = "2025.08.06.11.21+4c2e6d6"
lambda1_released_version = "2025.08.06.11.21+4c2e6d6"
lambda2_released_version = "2025.08.06.11.21+4c2e6d6"
lambda3_released_version = "2025.08.06.11.21+4c2e6d6"
