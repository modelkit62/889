# NAME IaC Repository

This repository intention is the IaC for a LZ workload account using Terraform. 
It contains Terraform to connect to the NAME-aws-lz-hub centralised network egress.
Some of the Terraform on this repository is still WIP.
At the moment it will display a Hello World typescript S3 hosted website.
The plan was to use Lambda's.

The Terraform code in this repository provisions and maintains AWS resources for NAME across to be deployed to the Test and Production environments.

The AWS accounts for these are provisioned by the Landing Zone.

The application logic for these resources are located within this [repository](tbc).

## Pre-Req's

* The NAME AWS accounts for Test and Production have been created via the AWS Landing Zone.
* You have user access to both AWS accounts.

### AWS S3 Bucket

* Either run the below AWS commands in each account via CloudShell or obtain AWS credentials from the SSO page and run them locally.
* Create the AWS S3 bucket to store the Terraform statefile using these commands:

```
aws s3api create-bucket --bucket NAME-<ENV>-terraform-state --create-bucket-configuration LocationConstraint=eu-west-2
```
```
aws s3api put-bucket-versioning --bucket NAME-<ENV>-terraform-state --versioning-configuration Status=Enabled
```

* The first Terraform apply will add the statefile to the AWS S3 bucket per account.

### IAM Role

* Create a AWS OIDC in each account so that the GitHub Actions `configure-aws-credentials` action will receives a JWT from the GitHub OIDC when the CI is executed. Follow these steps:

    1. Download the AWS CloudFormation [template](https://d38mtn6aq9zhn6.cloudfront.net/configure-aws-credentials-latest.yml) from the AWS GitHub repository.
    2. Log into each account and create a new AWS CloudFormation stack using the downloaded template file. The Stack will create a new IAM Role and a new AWS IAM Identity provider in the account for the GitHub Identity provider. Provide an IAM Role name called `NAME-<ENV>-account-deploy-role`, the NAME GitHub Organisation name and NAME Repository name details into the Stack form, and leave the other settings as default.
    3. Create and run the Stack.
    4. Open the Stack results to see that the new IAM Role and a new AWS IAM Identity provider resources were created.

    OR

    1. Create an AWS IAM Identity Provider in each AWS account, copy the output for use in Step 2:
    ```
    aws iam create-open-id-connect-provider --url https://token.actions.githubusercontent.com --client-id-list sts.amazonaws.com --thumbprint-list ffffffffffffffffffffffffffffffffffffffff
    ```
    2. Create a new AWS IAM Role, called `NAME-<ENV>-account-deploy-role`, in each AWS account that uses the Trust Policy from this [site](https://github.com/aws-actions/configure-aws-credentials?tab=readme-ov-file#quick-start-oidc-recommended). Update the Trust Policy to use the NAME GitHub Organisation name, the GitHub repository, use the AWS IAM Identity Provider value from Step 1 and change the branch to main.


* Create and add an AWS IAM Policy that will allow the AWS IAM Role to connect to AWS S3 in order to access the Terraform statefile when run the GitHub Actions. 

    1. Go to AWS IAM in each account and create a new Policy, called `NAME-<ENV>-deploy-role-policy` use the example from this [website](https://developer.hashicorp.com/terraform/language/backend/s3#s3-bucket-permissions) and apply the bucket arn, bucket name and object name. Then attach the policy to the IAM role.

    2. Create and add second AWS IAM Policy within each account that allows the Terraform code to update the AWS IAM Role with its own AWS IAM policies that are specific to the Terraform deployment. Name the IAM Policy `NAME-<ENV>-deploy-role-iam-policy`, use the below Policy and update the AWS account number. Then attach the policy to the IAM role.

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "iam:GetRole",
                "iam:UpdateRole",
                "iam:PutRolePolicy",
                "iam:GetRolePolicy",
                "iam:DeleteRolePolicy",
                "iam:AttachRolePolicy",
                "iam:ListAttachedRolePolicies",
                "iam:DetachRolePolicy",
                "iam:CreateRole",
                "iam:DeleteRole",
                "iam:TagRole",
                "iam:ListRolePolicies",
                "iam:ListInstanceProfilesForRole",
                "iam:PassRole"
            ],
            "Resource": "arn:aws:iam::<ACCOUNT-ID>:role/NAME-*"
        }
    ]
}
```

* Apply the AWS account ID number to the GitHub Action files in the `.github/workflow` folder in the section named `Map environment to AWS account ID`.

## Makefile

This repository leverages a Makefile to execute Terraform operations across multiple environments: test and prod.

### AWS Credentials Setup

Before running any Makefile commands locally:

* Navigate to the AWS SSO page.
* Retrieve and export your AWS credentials locally for either the NAME Test or Production account.

### Default Environment

* By default, the Makefile uses test as the active environment (ENV=test). This will execute Terraform logic using the NAME Test configuration (e.g., NAME-test resources and state).

To switch environments use these commands:

```
export ENV=test
```
```
make init
```

Alternatively set the setting `ENV=test` before the Makefile command like this:

```
ENV=test make init
```

### Switching to Production

* Obtain credentials via SSO for the Production account.
* Override the environment variable by setting `ENV=prod`. This will apply the NAME-prod configuration within the Terraform code.

To switch environments use these commands:

```
export ENV=prod
```
```
make init
```

Alternatively set the setting `ENV=prod` before the Makefile command like this:

```
ENV=prod make init
```


### The Makefile commands:

```
make init
```
```
make plan
```
```
make apply
```
```
make destroy
```
```
make format
```
```
make validate
```
```
make lint
```
```
make tidy
```
```
make clean
```

* The GitHub Action to deploy the Terraform to the AWS accounts will use the following command which uses the Terraform apply auto approve command. Ensure changes merged onto the main branch have been reviewed via a pull request:

```
make apply-ci
```
```
make destroy-ci
```

### Tips

* When re-deploying the configuration the CloudWatch log group from a previous deployment may still exist and prevent a successful Terraform Apply. Manually delete the CloudWatch log groups contained in the cloudwatch.tf file.

* Ensure **main branch protection** is applied on this repository to prevent commits directly to the main branch.

* If the **GitHub Action fails due to adding a new IAM policy**, re-run the failed job, on the next iteration it will assume the IAM role again with the new IAM policy changes applied.**

* If see a **Terraform statefile lock** issue. Copy the ID from the message and use the following command to unlock the file `terraform force-unlock ID`.

## Local Development

* It will be possible to run the Terraform locally if you have admin access to each account by using the AWS credentials from the SSO page.

* There is a AWS Control Tower SCP that protects the Network AWS Resources. It might prevent deployments.

* To use the correct Terraform version specified by the repository use the `tfswitch` tool if required.
