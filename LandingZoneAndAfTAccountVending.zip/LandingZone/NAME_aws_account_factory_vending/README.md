# NAME AWS LZ AFT Account Factory Vending

This is one of the repositories that is part of the AWS Control Tower Account Factory for Terraform (AFT) feature used on the NAME AWS Landing Zone. See the [Infrastucture team repositories](https://github.com/orgs/NAME/teams/infrastructure/repositories) to access the repositories.

* [NAME_aws_account_factory_vending](https://github.com/NAME/NAME_aws_account_factory_vending)
* [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations)
* [NAME_aws_lz_aft_account_provisioning_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_provisioning_customizations)
* [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) 
* [NAME_aws_lz_aft_global_customizations](https://github.com/NAME/NAME_aws_lz_aft_global_customizations)

## Intro

This repository contains a single Terraform file that is run once to boot strap the AFT feature into the NAME AWS LZ platform. 

It creates the AFT feature that is part of AWS Control Tower. 

There are pre-req steps below that need to be completed first.

The Terraform file requires the AWS account ID numbers created by the AWS LZA and the GitHub repository URL's listed in the team above.

The Terraform file is added here for DR purposes in case the AFT feature needs to be re-deployed.

When run the Terraform apply command on this Terraform file it will create new AWS resources mostly in the AFT account and some in the other LZ mandatory AWS accounts.

## Bootstrap Steps

* In Terminal ensure have terraform, aws and git tools installed.
* The following have already been created:
    1. The NAME AWS LZ
    2. The mandatory accounts (Management, Audit and LogArchive) via the LZ
    3. The AFT-Management OU via the LZ
    4. The AFT account in AFT-Management OU via the LZ
    5. The four GitHub repositories at the top of this README file with NAME configuration settings applied
* Have Admin permissions in the NAME AWS LZ root account.
* Get AWS credentials locally to run the Terraform commands and the AWS commands against the NAME AWS LZ root account.
* Create the AWS S3 Bucket and AWS DynamoDB table using these commands:

```
aws s3api create-bucket --bucket NAME-aws-lz-aftbootstrap-tfstate --create-bucket-configuration LocationConstraint=eu-west-2
```
```
aws s3api put-bucket-versioning --bucket NAME-aws-lz-aftbootstrap-tfstate --versioning-configuration Status=Enabled
```
```
aws dynamodb create-table --table-name NAME-aftbootstrap-state --attribute-definitions AttributeName=LockID,AttributeType=S --key-schema AttributeName=LockID,KeyType=HASH --provisioned-throughput ReadCapacityUnits=1,WriteCapacityUnits=1
```

* Check the AWS S3 Bucket and AWS DynamoDB table are created succesfully in the NAME AWS LZ root account.
* Deploy the AFT account AWS Resources by running the `terraform init`, `terraform plan `and `terraform apply` commands. **Re-run Terraform apply if see any AWS Lambda layer errors.** There is a race condition where something related to Lambda is not deployed so run it again.

## AFT Setup

After Terraform apply has been run succesfully, follow these steps to complete the AFT account setup:

1.  In the NAME AWS LZ root account, create a new user in the IAM Identity Center so can SSO into the other Landing Zone based AWS accounts.
2.	In GitHub and the AFT AWS account. Terraform apply AWS would have created a connection between the NAME GitHub Organisation and the AFT account using a AWS CodeStart connection. This connection might already exist on the NAME GitHub Organisation as part of the NAME AWS LZ set up. If need a new connection, ask the NAME GitHub Organisation admin to log into the AFT account as an admin, and go to the AWS CodeStar connection page, bottom left is the settings, click the `Update Pending Connection` button on the Pending item, and complete the connection attempt. Then in the GitHub Organisation settings App section approve the connection and allow access to the four repositories at the top of this readme file, so that the AWS CodePipeline can access them. Once the CodeStar connection says available then move to the next step.
4.	In the AFT account, in AWS CodePipeline there should be two pipelines one for the Request Account Terraform GitHub repository and another for the Global Customization Terraform GitHub repository. They should be in the failed state because the connector in the previous step wasn’t set up correctly. Re-run the Request Account AWS CodePipeline process and it should create a new AWS account (if exists in the Request Account Terraform GitHub repository ). Then re-run the Global Customization AWS CodePipeline process to apply any changes from that repository.
5.	In the AFT account, go to the AWS Step functions to see that there is a state machine called “aft-account-provisioning-framework”. If open it and look at the state machine instance diagram it might have failed. There might be a race condition in the first deployment, and it just needs to be re-run. Try re-running the whole Step Function. If it fails again try adding the AWSAFTExecution IAM role to the "Control Tower management account portfolio" product in AWS Service Catalog on the root LZ account. It should have AWSAFTService already.
6.	In the AFT account, the state machine called “aft-account-provisioning-framework” in AWS Step functions will then call the other three state machines that can be seen in the AFT account. One of these will delete the default VPC in the new account, enable CloudTrail and enrol Enterprise Support. 
7.	In the AFT account, open AWS CodePipeline to see if the new pipeline called xyz-customizations-pipeline passes or fails.
8.	At this point, a commit to the main branch of the Request Account Terraform GitHub repository or Global Customization Terraform GitHub repository should start the AWS CodePipeline processes in the AFT account, which will start the AWS Step functions.
