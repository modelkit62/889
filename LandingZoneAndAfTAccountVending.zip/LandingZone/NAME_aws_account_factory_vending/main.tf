provider "aws" {
  region              = "eu-west-2"
  shared_config_files = ["%USERPROFILE%/.aws/config"]
}

terraform {
  backend "s3" {
    bucket         = "NAME-aws-lz-aftbootstrap-tfstate"
    key            = "state/terraform.tfstate"
    region         = "eu-west-2"
    dynamodb_table = "NAME-aftbootstrap-state"
  }
}

module "aft_pipeline" {
  source = "github.com/aws-ia/terraform-aws-control_tower_account_factory"

  # Required Variables
  ct_management_account_id  = "?"
  log_archive_account_id    = "?"
  audit_account_id          = "?"
  aft_management_account_id = "?"
  ct_home_region            = "eu-west-2"

  # Terraform variables
  terraform_version      = "1.6.0"
  terraform_distribution = "oss"

  # VCS Vars
  vcs_provider                                  = "github"
  account_request_repo_name                     = "GH-ORG-NAME/NAME_aws_lz_aft_account_request"
  global_customizations_repo_name               = "GH-ORG-NAME/NAME_aws_lz_aft_global_customizations"
  account_customizations_repo_name              = "GH-ORG-NAME/NAME_aws_lz_aft_account_customizations"
  account_provisioning_customizations_repo_name = "GH-ORG-NAME/NAME_aws_lz_aft_account_provisioning_customizations"

  # AFT Feature flags
  aft_feature_cloudtrail_data_events      = false
  aft_feature_enterprise_support          = false
  aft_feature_delete_default_vpcs_enabled = true

  # AFT Additional Configurations
  aft_enable_vpc                            = false
  backup_recovery_point_retention           = 1
  log_archive_bucket_object_expiration_days = 1
}
