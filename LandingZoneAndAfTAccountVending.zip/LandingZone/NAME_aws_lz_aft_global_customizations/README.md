# NAME AWS LZ AFT Global Customizations

This is one of the repositories that is part of the AWS Control Tower Account Factory for Terraform (AFT) feature used on the NAME AWS Landing Zone. See the [Infrastucture team repositories](https://github.com/orgs/NAME/teams/infrastructure/repositories) to access the repositories.

* [NAME_aws_account_factory_vending](https://github.com/NAME/NAME_aws_account_factory_vending)
* [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations)
* [NAME_aws_lz_aft_account_provisioning_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_provisioning_customizations)
* [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) 
* [NAME_aws_lz_aft_global_customizations](https://github.com/NAME/NAME_aws_lz_aft_global_customizations)

## Intro

This repository is used to define the global customizations that is applied to all the vended AWS accounts that are created using the AFT feature. All accounts vended by AFT will have these customizations applied.

This repository is best for customizations that are always required for all accounts. 

Examples:
•	Basic compliance requirements such as setting IAM password policies.
•	Deploying centralised or commonly used IAM roles and policies.
•	Deploying S3 buckets or Lambda functions required for routine account management tasks.

## Directory Info

In the root folder directory is a `api_helpers` folder and `terraform` folder where custom configuration can be added.

If your custom configurations is in the form of Python programs or scripts, place those under `api_helpers/python` folder in your repository.

If your custom configurations is in the form of Bash scripts, place those under `api_helpers` folder in your repository.

If your custom configurations is in the form of Terraform, place those under the `terraform` folder in your repository.

## API Helpers
The purpose of API helpers is to perform actions that cannot be performed within Terraform.

### Python
The api_helpers/python folder contains a requirements.txt, where you can specify libraries/packages to be installed via PIP.

### Bash
This is where you define what runs before/after Terraform, as well as the order the Python scripts execute, along with any command line parameters. These bash scripts can be extended to perform other actions, such as leveraging the AWS CLI or performing additional/custom Bash scripting.

- pre-api-helpers.sh - Actions to execute prior to running Terraform.
- post-api-helpers.sh - Actions to execute after running Terraform.

### Sample api-helpers.sh

Sample #1 - Using AWS CLI to query for resources, save to a variable, and then pass to a script. In the example below, all running instances are queried, stopped, and started using AWS CLI and custom Python scritpts.
```
instances=$(aws ec2 describe-instances --filters "Name=instance-state-name,Values=running")
python ./python/source/stop_instances.py --instances $instances
sleep 10s
python ./python/source/start_instances.py --instances $instances
```

Sample #2 - Query a 3rd party IPAM solution, and save the given CIDR to AWS Parameter Store. This SSM parameter could be leveraged from Terraform using a data object to create a VPC.
```
account = $(aws sts get-caller-identity --query Account --output text)
region = $(aws ec2 describe-availability-zones --query 'AvailabilityZones[0].[RegionName]' --output text)
cidr = $(python ./python/source/get_cidr_range.py)
aws ssm put-parameter --name /$account/$region/vpc/cidr --value $cidr
```
