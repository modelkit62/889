# NAME AWS Landing Zone Configuration

This repository contains the [AWS Landing Zone](https://aws.amazon.com/solutions/implementations/landing-zone-accelerator-on-aws) (LZ) configuration files that are used on the root AWS account in the NAME Landing Zone environment.

Pushes to the main branch on this repository will start a AWS CodePipeline run, on the root account, that will update the AWS LZ accounts and configuration. 

**Ensure main branch protection is enabled on this repository to prevent direct commits to main.**

Once the AWS CodePipeline run has started there is a **manual approve stage** that needs to be actioned for the changes to be applied.

This repository is based on the [AWS LZA repository](https://github.com/awslabs/landing-zone-accelerator-on-aws/tree/release/v1.12.2) version 1.12.2. 

All the possible configuration settings for the .yaml files in this repository are specified on this [AWS website](https://awslabs.github.io/landing-zone-accelerator-on-aws/latest/typedocs/modules/___packages__aws_accelerator_config_lib_models_accounts_config.html).

## LZ Setup

1.	Have an admin email account can use for the root account and platform emails.
2.	Create a new root AWS accounted.
3.	Create an AWS IAM user with full access to deploy the LZ.
4.	Pick a region to deploy to.
5.	Create a GitHub account.
6.	Create a repository to store the AWS LZ config files.
7.	Create a GitHub PAT token using with the public_repo option applied.
8.	In the root AWS account open https://eu-west-2.console.aws.amazon.com/servicequotas/home/services/codebuild/quotas and check the “Concurrently running builds for Linux/Large environment” value is larger than 3.
9.	Save the GH PAT token to the AWS root account as a plain text AWS secret following these [steps](https://docs.aws.amazon.com/solutions/latest/landing-zone-accelerator-on-aws/prerequisites.html#create-a-github-personal-access-token-and-store-in-secrets-manager).
10.	Create an AWS Organisation in the root account.
11.	Can download and view the latest template from this [site](https://docs.aws.amazon.com/solutions/latest/landing-zone-accelerator-on-aws/aws-cloudformation-template.html).
12.	Follow the steps in the AWS LZ [site](https://docs.aws.amazon.com/solutions/latest/landing-zone-accelerator-on-aws/step-1.-launch-the-stack.html). Specify the correct the region before creating the stack. Use the S3 option and default option for everything else.
13.	Wait a long time for it to deploy. There is a manual approve stage in AWS CodePipeline during the process in the root account.

## Post LZ Deployment

1.	Create this repository.
2.	Download the LZ generated config files from the AWS S3 bucket in the Root account. The LZ config files from the initial deployment are added to an AWS S3 bucket in the root account.
3.	Add the files to this GitHub repository.
4.	Go to the AWS CodePipeline settings -> Connections in the root account. Create a new GitHub connection between the GitHub Organisation and pick this GitHub repository.
5.	Have a GitHub Organisation admin approve the AWS GitHub App connection, who also has access the LZ root account. It should say available if the connection was created correctly.
6.	In the root account go to the AWSAccelerator-InstallerStack in AWS CloudFormation.
7.	Select update the stack and change the config option from S3 to use the AWS CodeConnection resource just created and use the NAME GitHub Organisation name and name of this repository.
8.	Go to AWS CodePipeline, select the AWSAccelerator-Installer and click on the release change button. This will run the full pipeline again but using the config files from this repository.
9.	Attempt a change on this repository main branch and check it starts a new AWS CodePipeline process.
10.	Apply branch protection on commits to the main branch on this repository.

At this point the next steps are to configure the LZ config files, create the OU's, accounts and deploy to the root account.

Once this is done the next step is to enable the AWS Control Tower AFT feature following the steps in this [repository](https://github.com/NAME/NAME_aws_account_factory_vending), which is used to create the Workload AWS accounts via Terraform and AWS CodePipeline.

## Good to Know Tips

* Any errors or problems check the [AWS LZA GitHub repository issues](https://github.com/awslabs/landing-zone-accelerator-on-aws/issues) first to see if someone has seen a similar problem and solution.
* Check the [known problem solutions](https://docs.aws.amazon.com/solutions/latest/landing-zone-accelerator-on-aws/known-issue-resolution.html) on the LZA documentation site.
* We cannot create new AWS accounts in the Security OU. It has protection against this.
* If you see a CI/CD error in the Account stage in AWS CodePipeline deployment related to “create<AWS-Resource>ServiceLinkedRole” the fix is to re-try the failed Account stage multiple times. This might be a LZA [bug](https://github.com/awslabs/landing-zone-accelerator-on-aws/issues/237#issuecomment-2079958097). 
* If the CI/CD error in the Account stage failed multiple times and now states `UPDATE_ROLLBACK_FAILED` then go to AWS CloudFormation in `us-east-1` and manual select the `Continue update rollback` under the Stack actions button. It should turn to UPDATE_ROLLBACK_COMPLETE state. Then re-run the Account stage again.
* By default, users will not have Admin access to the created AWS accounts in the LZ. To get Admin access create a new group in IAM Identity Center, and in the Permission set for the group add the AWS account and the admin role. Log in via the SSO page to access the account as the Admin.
* To trigger AWS CodePipeline on a repository use: `git commit --allow-empty -m "Run CodePipeline"` and create a new pull-request. Or start it from AWS CodePipeline in the root account.
* Once AWS Identity Center SSO is set up you can log in as a admin on the account using IAM roles in the SSO screen. The URL link is in AWS Identity Center.
* **When adding a new OU ensure the SCPs are applied to the new OU via the `serviceControlPolicies` section of the `organization-config.yaml` to protect the LZ AWS resources in the new OU AWS accounts.**
* When using the `deploymentTargets: / organizationalUnits:` setting it does not apply changes to nested OUs, you have to explicitly define each OU in the list.
* When the LZ CI/CD in CodePipeline starts in the root account, it can fail a fair bit, so it’s worth keeping an eye on it for failures once start a new run.
* When creating an IAM Identity Center Group to access other LZ accounts, you have to log into the root account as an admin user to assign AWS IAM permissions to the Group. It cannot be done from the Audit account.

## AFT

Workload OU AWS accounts are created via the AFT feature, see the [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) repository to add new workload AWS accounts.

Once the new AWS account is created via AFT add it to the `accounts-config.yaml` file in this format:

```
  - name: account-name
    description: example
    email: NAMEawslz+example@NAME.com
    organizationalUnit: Workloads/Non-Production
```

Merge this change onto the main branch in order to start a new run of the Landing Zone AWS CodePipeline CI/CD and complete the manual approve step in the root account. 

This will create a reference related to the new AWS account in the AWS CloudFormation stack, because it has no awareness of the new account when it does a comparison with AWS Organisation and AWS Control Tower.

## To Move an Account from OU to OU in the LZ

1.	Ensure the destination OU exists in the `organization-config.yaml` file and deploy it.
2.	In the AWS Control Tower, go to the account and un-enrol it. This should place the account into the root of AWS Control Tower and it will remove the account reference in AWS Service Catalog.
3.	Modify the `accounts-config.yaml` file to move the account to the destination OU and deploy it. AWS Control Tower will enrol the account into the destination OU, and create a new account reference in AWS Service Catalog.

**If you see a CI/CD error in the Account stage in AWS CodePipeline deployment related to “create<AWS-Resource>ServiceLinkedRole” the fix is to re-try the Account stage multiple times. This might be a LZA bug.**

## To Remove an Account from the LZA and Close the Account

1.	Ensure the SuspendedAccounts OU exists. Create it in `organization-config.yaml` if missing.
2.	In the AWS Root account UI, open AWS Organisation or AWS Control Tower, select the account to be removed, and move the account to the SuspendedAccounts OU.
3.	In the config file `accounts-config.yaml` remove the account and push to main.
4.	After CodePipeline is finished can either use the AWS Organisation in the Root account to close the account following this [guide](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_accounts_close.html) or log into the AWS account as the root user and close the account following this [guide](https://docs.aws.amazon.com/accounts/latest/reference/manage-acct-closing.html#close-account-procedure).

If there is a pipeline error related to CloudFormation being in the UPDATE_ROLLBACK_FAILED state then follow this [guide](https://docs.aws.amazon.com/solutions/latest/landing-zone-accelerator-on-aws/problem-account-enrollment-and-environment-validation-failures.html). Ensure the AWS Service Catalog opens in the correct Region and terminate the account that failed. Then roll back the CF prepare stack. Can then push changes to main branch to start a new pipeline.

Then go to the AFT AWS account and related repositories to delete the AWS account from them as well:

1. Record the AWS account number ID to be deleted.
2. Delete the account from the [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) repository and the [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations) repository. Push the changes to each main branch. After that need to clean up the AWS S3 buckets and DynamoDB tables in the AFT account.
3. Go to the AFT account AWS S3 bucket called `aft-backend-ABC-primary-region` and remove the items that have a matching AWS account number ID to be deleted.
4. Delete the AWS S3 bucket that has a matching AWS account number ID to be deleted.
5. Go to the AFT account DynamoDB table called `aft-backend-ABC`, explore the items and delete any items that have a matching AWS account number ID to be deleted.
6. Go to the AFT account DynamoDB table called `aft-request-audit`, explore the items and delete any items that have a matching AWS account number ID to be deleted.

## AWS LZ Info

AWS have created a Landing Zone Accelerator (LZA). This is a public repository. It uses AWS CDK in Typescript define the AWS resources. The AWS Root account needs to be created first with a blank AWS Organisation added in the Root account. It comes with default configuration files that are applied when it is deployed. In the first deployment it will create an AWS Control Tower in the AWS Organisation in the Root account. AWS Control Tower and AWS Organisation are used to create a Log AWS account and a Audit AWS account. The first resources it creates when run the solution is an AWS LZA installer stack into AWS CloudFormation that generates the AWS CodePipeline CI/CD. This pipeline creates a connection to the public AWS GitHub AWS LZA source repository. It stores the initial config files to an S3 bucket. It will then run the AWSAccelerator-Pipeline in AWS CodePipeline CI/CD that will manage the landing zone deployment and customization. This creates the initial landing zone using the default configuration files. It will create AWS resources in the root account that are used by the AWS LZ for future deployments, account creation (if used) and drift detection. After deployment we move the config files from S3 to the NAME GitHub repository instead.

It needs a mandatory Root or Management account that handles the global configuration management and billing consolidation. It creates the mandatory LogArchive and Audit accounts. Extra account are optional. The LogArchive account is used for centralized logging of AWS service logs and AWS CloudTrail trails. The Audit account is used to centralize all security operations and management activities. This account is typically used as a delegated administrator of centralized security services such as Amazon Macie, Amazon GuardDuty, and AWS Security Hub.

When a new AWS CloudWatch Log Group is created in any account, the data is streamed to the Log account via AWS Kinesis by default.

If you sign in as a user in the management account, you can perform any operation that is allowed by your IAM permissions policies. The SCPs don't affect any user or role in the management account.

The LZA will deploy some of the CloudFormation stacks to us-east-1 as this is the Global region for Global AWS Resources, do not add any SCP or deny settings that prevent access to us-east-1. Its mentioned a bit loosely in the [pre-req's site](https://docs.aws.amazon.com/solutions/latest/landing-zone-accelerator-on-aws/prerequisites.html).

## AWS Services in a Landing Zone

1.  AWS Control Tower: Automates multi-account setup and governance.
2.  AWS Organizations: Manages multiple AWS accounts with centralized policies.
3.  AWS IAM & IAM Identity Center (SSO): Provides identity and access management.
4.  AWS CloudTrail: Enables logging and auditing of account activities.
5.  AWS Config: Tracks configuration changes and compliance.
6.  AWS Security Hub: Monitors security best practices across accounts.
7.  AWS GuardDuty: Detects threats and anomalies in AWS environments.
8.  AWS VPC & AWS Transit Gateway: Manages networking and connectivity.
9.  AWS Route 53: Provides DNS management for multi-account setups.
10. AWS S3 & AWS Backup: Stores logs, configurations, and backups.
11. AWS Service Catalog: Helps deploy pre-approved resources efficiently.
12. AWS CloudFormation: Automates infrastructure deployment using templates.
13. AWS Budgets & Cost Explorer: Tracks and optimizes cloud spending.

## SCPs

In the service-control-policies folder are four json files containing SCPs: GuardRails 1, 2, 3 and quarantine.

The SCPs can be applied via the `organization-config.yaml` file.

SCP’s in place:

1.	 guardrails-1.json: This SCP has restrictions that prevent manipulating or deleting:
    a.	AWS Config rules across all accounts.
    b.	Any specific Lambda functions related to the accelerator.
    c.	SNS changes related to the accelerator.
    d.	CloudWatch Logs changes related to the accelerator.
    e.	AWS Control Tower log file changes in S3.
    f.	Amazon EBS encryption in all accounts. 
    g.	KMS Keys changes across all accounts

2.	 guardrails-2.json: This SCP has restrictions that prevent manipulating or deleting:
    a.	IAM user, IAM Alias accounts, IAM password policy changes across all accounts.
    b.	IAM changes related to the accelerator.
    c.	GuardDuty and Security Hub changes across all accounts.
    d.	Macie changes across all accounts.
    e.	CloudFormation delete related to the accelerator.
    f.	SSM Parameter Store delete related to the accelerator.
    g.	CloudTrail changes related to the accelerator.
    h.	S3 bucket setting changes related to the accelerator.

3.	guardrails-3.json: This SCP has restrictions that prevent manipulating or deleting:
    a.	EC2 network security setting changes across all accounts.
    b.	AWS RAM (share AWS resources across accounts) changes across all accounts.

4.	quarantine.json: This SCP is used to prevent changes to new accounts until the LZA has been executed successfully and control applied.

The Landing Zone will only manage the SCPs that are listed in the repository, and will not manage any SCPs that are deployed by AWS Control Tower. 

**Note: Organizations have a limit of 5 SCPs directly attached per Organisation Unit. AWS Control Tower will consume some of the SCP space. If run out of SCP spaces, create a nested OU. The sub OU inherits the above OU SCPs so it will have more SCP space. Each OU can have multiple inherited SCPs that don’t apply to the five SCP limit.**

SCPs are protected from changes by enabling the scpRevertChangesConfig option in the `security-config.yaml` configuration file. This configuration property will monitor for manual changes to SCPs and revert them. This is enabled by default in the sample configuration.

SCPs are used to specifically deny access to AWS resources. The SCP doesn’t grant actual IAM permissions to users, groups, or roles in the AWS account, the purpose of the SCP is to say what can/cannot be accessed. AWS IAM permissions still need to be given in the AWS account to the users, groups, or roles. The SCPs are evaluated before the IAM policies when an API call is made, thus the SCP can block access even if the IAM policy allows the action.

Each AWS account and OU has directly attached the FullAWSAccess SCP policy. This is applied directly to the account or OU. Nested AWS accounts and OU’s will also inherit the FullAWSAccess SCP policy from above. The policy allows all AWS actions on all AWS resources. This is used to allow access to the AWS resources. If this policy is missing from an account or OU if won’t be able to do anything unless there is a replacement SCP that allows specific actions that are allowed on the account or OU.

Each OU or AWS account is allowed only five directly attached SCPs. Each OU or AWS account can have many inherited SCPs that are not part of the five SCP limit. The LZ provides SCP’s that protect the Security OU and Infrastructure OU AWS resources.

* The Security OU has five SCP’s attached directly: AcceleratorGuardrails1, and 2, FullAWSAccess, aws-guardrails-IWLXgI, aws-guardrails-QWcgdH (created by control tower).
* The Infrastructure OU has five SCP’s attached directly: AcceleratorGuardrails1, 2, and 3, FullAWSAccess, aws-guardrails-VnjDZG (created by control tower).

Because of the way SCP are either directly attached to the OU or inherited from a base OU the Workload OU has this setup:

* The Workloads OU has two SCP’s attached directly: FullAWSAccess and aws-guardrails-oFwMLr (created by control tower). 
* It has three spare SCPs slots available.
* The nested OUs in the Workloads OU each OU has the one SCP attached directly: FullAWSAccess. 
* Each nested OU has four spare SCPs slots available.

**Therefore use nested OU's to add more SCPs to an OU.**

**The SCPs that are part of the LZ used by the Security OU and Infrastructure OU are at their maximum character limit so cannot add more content to them.**

**The Security OU and Infrastructure OU have reached their maximum five SCP limit.**

Lots of AWS Control Tower controls are added mandatory by AWS Control Tower to the LZ related OUs. See the list [here](https://docs.aws.amazon.com/controltower/latest/controlreference/mandatory-controls.html). These are the SCP policies that AWS Control Tower apply to the OU that take up some of the five available SCP spaces on the OU.

## AWS Accounts 

The following are mandatory accounts created by the LZ:

* Management account: This account is designated when first creating an AWS Organization. It’s a privileged account where all AWS Organizations global configuration management and billing consolidation occurs. Added to the Root OU.
* LogArchive account: This account is used for centralized logging of AWS service logs and AWS CloudTrail trails. Added to the Security OU.
* Audit account: This account is used to centralize all security operations and management activities. This account is typically used as a delegated administrator of centralized security services such as Amazon Macie, Amazon GuardDuty, and AWS Security Hub. Added to the Security OU.

Other accounts:

* Workloads: Contains the dev, stage, prod, etc accounts for workloads. Added to the Workloads OU.
* Network: Contains the network hub AWS Transit Gateway. Added to the Infrastructure OU.
* Identity: Contains AWS Cognito to enable user access to applications. Not used for access to LZ related AWS accounts. Added to the Infrastructure OU.
* AFT: This is used by the AWS Control Tower Account Factory via Terraform (AFT) to provision new AWS accounts. Added to the AFT OU.

## AWS Config Rules and AWS Control Tower Rules

In the LZ config file `security-config.yaml` are the custom AWS Config rules that are applied to the Root OU by the LZ. This applies to all nested OUs and AWS accounts. Use this [AWS website](https://docs.aws.amazon.com/config/latest/developerguide/managed-rules-by-aws-config.html) to see the full list of possible AWS Config rules. See the section called “awsConfig/ruleSets”

In the LZ config file `global-config.yaml` are the custom AWS Control Tower rules. To see the full list of the possible AWS Control Tower rules open the root account, go to AWS Control Tower and select the Control catalog option. This will provide the list of rules. Only the [strongly recommended or elective](https://docs.aws.amazon.com/controltower/latest/controlreference/strongly-recommended-controls.html) AWS Control Tower controls are allowed via the .yaml file. Open a rule and use the Alias name in the Terraform file to apply it: in the section called `controlTower/controls/controlTowerControls`. When AWS Control Tower is enabled it creates mandatory rules that are applied to the OUs, they are listed [here](https://docs.aws.amazon.com/controltower/latest/controlreference/controls-reference.html).

Lots of AWS Control Tower controls are added mandatory by AWS Control Tower to the LZ related OU’s. See the list [here](https://docs.aws.amazon.com/controltower/latest/controlreference/mandatory-controls.html).

## AWS Billing

The AWS Billing and Cost Management by default only allows the root user account access to the information. The root user can log in and enable access to AWS Billing by following this [guide](https://docs.aws.amazon.com/IAM/latest/UserGuide/getting-started-account-iam.html). For AWS Identity Center users create a new Group with the Billing permission applied on the Root account. This will provide nearly full access to AWS Billing and Cost Management.
