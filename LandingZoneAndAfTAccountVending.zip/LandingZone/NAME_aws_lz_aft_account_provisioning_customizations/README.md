# NAME AWS Landing Zone AFT Account Provisioning Customizations

This is one of the repositories that is part of the AWS Control Tower Account Factory for Terraform (AFT) feature used on the NAME AWS Landing Zone. See the [Infrastucture team repositories](https://github.com/orgs/NAME/teams/infrastructure/repositories) to access the repositories.

* [NAME_aws_account_factory_vending](https://github.com/NAME/NAME_aws_account_factory_vending)
* [NAME_aws_lz_aft_account_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_customizations)
* [NAME_aws_lz_aft_account_provisioning_customizations](https://github.com/NAME/NAME_aws_lz_aft_account_provisioning_customizations)
* [NAME_aws_lz_aft_account_request](https://github.com/NAME/NAME_aws_lz_aft_account_request) 
* [NAME_aws_lz_aft_global_customizations](https://github.com/NAME/NAME_aws_lz_aft_global_customizations)

## Intro

This repository is used to set up new AWS account customizations using a AWS Step Functions state machine.

The Terraform in the repository is used to define the customizations that will be applied to the new AWS accounts during the provisioning process. This is a one off stage during the initial provisioning customization of the account.

These customizations are added here when the AFT cannot handle such things, such as running a specific approval workflow or creating additional users.

At the moment this repo is not currently leveraged by the NAME AWS LZ platform and no customizations are currently defined. It can be used as and when needed.
